<template>
	<div class="management-wrap">
		<el-dialog :title="title" :visible.sync="dialogWin" :show-close="false" :close-on-click-modal="false">
			<el-form :model="form" :rules="rulesForm" ref="form" label-width="140px">
				<el-input v-model="form.publishid" type="hidden" auto-complete="off"></el-input>
				<el-input v-model="form.aid" type="hidden" auto-complete="off"></el-input>
        <el-row>
          <el-col :span="9">
            <el-form-item label="产线："  prop="productlinename">
              <el-select v-model="form.productlinename" @change="changePridLine">
                <el-option v-for="option in prodLine" :label="option.name" :value="option.abbrname" :key="option.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="9">
            <el-form-item label="应用："  prop="applicationname" ref="appName">
              <el-select v-model="form.applicationname" @change="getAppNameId">
                <el-option v-for="item in appNameOptions" :label="item.name" :value="item.abbrname" :key="item.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
				<el-row>
					<el-col :span="9">
						<el-form-item label="type："  prop="type">
							<el-select v-model="form.type" @change="changeFormType">
								<el-option label="topic" value="EXCHANGETYPE.3"></el-option>
								<el-option label="fanout" value="EXCHANGETYPE.1"></el-option>
								<!-- <el-option label="headers" value="EXCHANGETYPE.2"></el-option> -->
								<el-option label="direct" value="EXCHANGETYPE.0"></el-option>
							</el-select>
					    </el-form-item>
					</el-col>
				</el-row>
				<el-form-item label="Routing key："  prop="routingkey" :class="routingkey" >
			      <el-input v-model="form.routingkey" placeholder="请输入Routing key" auto-complete="off"></el-input>
			    </el-form-item>

				<el-form-item label="queue名称："  prop="queue" :class="queueClass">
			      <el-input v-model="form.queue" placeholder="请输入queue名称" auto-complete="off"></el-input>
			    </el-form-item>
				<el-row>
					<el-col :span="18">
						<el-form-item label="Exchange名称："  prop="exchangename" ref="exchangename" :show-message="showMessage">
					    	<el-input v-model="form.exchangename" :disabled="disabledInput" placeholder="请输入exchange名称" auto-complete="off"></el-input>
					    </el-form-item>
					</el-col>
					<el-col :span="4"  ref="default" :class="hide">
						<el-checkbox class="checked" v-model="form.checked" @change="changeExchange">DEFAULTEXCHANGE</el-checkbox>
					</el-col>
				</el-row>
			    <el-row>
					<el-col :span="9">
					    <el-form-item label="是否持久化："  prop="durable">
							<el-select v-model="form.durable">
								<el-option label="是" value="DURABLE.1"></el-option>
								<el-option label="否" value="DURABLE.0"></el-option>
							</el-select>
					    </el-form-item>
				    </el-col>
			    </el-row>
			    <el-row>
					<el-col :span="9">
					    <el-form-item label="是否自动删除："  prop="autodelete">
							<el-select v-model="form.autodelete">
								<el-option label="是" value="AUTODELETE.1"></el-option>
								<el-option label="否" value="AUTODELETE.0"></el-option>
							</el-select>
					    </el-form-item>
				    </el-col>
				</el-row>
				<el-row>
					<el-col :span="9">
					    <el-form-item label="是否internal："  prop="internal">
							<el-select v-model="form.internal">
								<el-option label="是" value="INTERNAL.1"></el-option>
								<el-option label="否" value="INTERNAL.0"></el-option>
							</el-select>
					    </el-form-item>
					</el-col>
				</el-row>
			    <el-form-item label="创建者："  prop="creater">
			      <el-input v-model="form.creater" placeholder="请输入创建者" auto-complete="off"></el-input>
			    </el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
			    <el-button type="text"  @click="resetForm('form')">取 消</el-button>
			    <el-button type="primary"  @click="submitForm('form')">提 交</el-button>
			</div>
		</el-dialog>
		<div class="management-hd">
			<el-form :model="searchForm" :inline="true" label="90px">
				<proLineApp @ievent = "ievent"></proLineApp>
				<el-button type="primary" @click="filterList"  icon="search">搜索</el-button>
			</el-form>
		</div>
		<div class="management-bd">
			<el-table :data="listPage" border>
				<el-table-column prop="exchangename" label="Exchange名称" width="140"></el-table-column>
				<el-table-column prop="productlinename" label="产线"></el-table-column>
				<el-table-column prop="applicationname" label="应用" width="200"></el-table-column>
				<el-table-column prop="typename" label="type" width="80"></el-table-column>
				<el-table-column prop="queue" label="queue"></el-table-column>
				<el-table-column prop="routingkey" label="Routing key" width="120"></el-table-column>
				<el-table-column prop="durablename" label="是否持久化" width="120"></el-table-column>
				<el-table-column prop="autodeletename" label="是否自动删除"  width="120"></el-table-column>
				<el-table-column prop="internalname" label="是否internal" width="120"></el-table-column>
				<el-table-column prop="creater" label="创建人"></el-table-column>
				<el-table-column prop="birthtime" label="创建时间" width="180"></el-table-column>
				<el-table-column prop="checkstatusname" label="审核状态"></el-table-column>
				<el-table-column label="操作">
			      <template scope="scope">
			        <el-button type="text" size="small" @click="update(scope.row)" v-if='scope.row.checkstatus != "CHECKSTATUS.1"'>修改</el-button>
			      </template>
			    </el-table-column>
			</el-table>
		</div>
		<div class="management-ft">
			<el-pagination @current-change="currentChange" :current-page.sync="firstPage" layout="total,prev, pager, next" :page-size="pageSize" :total="totalSize" v-if="totalSize > 0">
			</el-pagination>
		</div>
	</div>

</template>
<script>
	import proLineApp from '../prodlineapp'
	export default {
		data(){
			var validateExchangeName = (rule, value, callback) => {
				if(value === ''){
					callback(new Error('请输入exchange名称'));
				}else{
					var reg = /^[*._/\-|A-Za-z0-9]{1,255}$/;
					if(reg.test(value)){
						callback();
					}else{
						callback(new Error('exchangename只能是数字、字母，不能含有特殊字符且长度不能大于255'));
					}
				}
			};
			var validateCreater = (rule, value, callback) => {
				if(value === ''){
					callback(new Error('请输入creater'));
				}else{
					var reg = /^[\u4e00-\u9fa5/A-Za-z0-9]{1,30}$/;
					if(reg.test(value)){
						callback();
					}else{
						callback(new Error('创建者只能是数字、字母，汉字，不能含有特殊字符且长度不能大于30'));
					}
				}
			};
			return{
				firstPage:1,
				pageSize:10,
				totalSize:'',
				title:'新增Exchange',
				dialogWin:false,
				disabledInput:false,
				hide:'hide',
				routingkey:'',
				queueClass:'',
				form:{
					exchangename:'',
					productlinename:'',
					applicationname:'',
					type:'',
					queue:'',
					routingkey:'',
					durable:'是',
					autodelete:'是',
					internal:'是',
					creater:'',
					defaultexchange:'',
					checked:'',
					publishid:'',
					aid:''
				},
				rulesForm:{
					type:[
						{ required:true, message:'请输入exchange名称', trigger:'change'}
					],
					exchangename:[
						{ required:true, validator:validateExchangeName, trigger:'blur'},
					],
					queue:[
						{ required:true, message:'请输入queue名称', trigger:'blur'}
					],
					productlinename:[
						{ required:true, message:'请选择产线', trigger:'change'}
					],
					applicationname:[
						{ required:true, message:'请选择应用', trigger:'change'}
					],
					routingkey:[
						{ required:true, message:'请输入routingkey', trigger:'blur'}
					],
					creater:[
						{ required:true, validator:validateCreater, trigger:'blur'}
					]
				},
				list:[],
				listPage:[],
				prodLine:'',
				appNameOptions:'',
				showMessage:true,
				searchForm:{
					prodLine:'',
					appName:'',
					pid:'',
					aid:''
				}
			}
		},
		components:{
			proLineApp
		},
		mounted(){
			this.getAllExchange();

		},
		methods:{
			ievent(...data){
				this.searchForm.prodLine = data[0].productline;
				this.searchForm.appName = data[0].application;
				this.searchForm.pid = data[0].pid;
				this.searchForm.aid = data[0].aid;
			},
			filterList(){
				if(this.searchForm.prodLine == ""){
					this.getAllExchange();
				}else{

					var str = {
						productLineId:this.searchForm.pid,
						applicationid:this.searchForm.appName == ""?"":this.searchForm.aid
					}
					this.$store.dispatch('getByProductLineOrApplicationId',str).then(val =>{
						this.list = val;
						this.totalSize = val.length;
						if(this.totalSize <= this.pageSize){
		  					this.listPage = this.list.slice('0',this.list.length)
		  				}else{
		  					this.listPage = this.list.slice('0',this.pageSize)
		  				}
					})
				}
			},
			getAllProductLine(){
				this.$store.dispatch('getAllProdLineList').then(val => {
	  				this.prodLine = val;
	  			})
			},
			getAllExchange(){
				this.$store.dispatch('getAllExchange').then(val =>{
					for(var item in val){
						var time = val[item].birthtime.slice(0,val[item].birthtime.length-2);
						val[item].birthtime = time
					}
					this.list = val;
					this.totalSize = val.length;
					if(this.totalSize <= this.pageSize){
	  					this.listPage = this.list.slice('0',this.list.length)
	  				}else{
	  					this.listPage = this.list.slice('0',this.pageSize)
	  				}
				})
			},
			currentChange(val){
		    	this.listPage = this.list.slice((val - 1)*this.pageSize,(val - 1)*this.pageSize+this.pageSize);
		    },
			update(row){
				this.dialogWin = true;
				this.title = '修改Exchange';

				this.form = {
					exchangename:row.exchangename,
					productlinename:row.productlineabbrname,
					applicationname:row.applicationabbrname,
					type:row.type,
					queue:row.queue,
					routingkey:row.routingkey,
					durable:row.durable,
					autodelete:row.autodelete,
					internal:row.internal,
					creater:row.creater,
					defaultexchange:row.defaultexchange,
					publishid:row.publishid,
					aid:row.aid
				}
				if(this.form.type == 'EXCHANGETYPE.0'){
					if(this.form.exchangename == ""){
						this.disabledInput = true;
						this.rulesForm.exchangename.pop();
						this.routingkey = 'hide';
						this.rulesForm.routingkey[0].required = false;
						this.form.checked = true;
						this.form.defaultexchange = 'DEFAULTEXCHANGE.1';
						this.queueClass = 'show';
						this.rulesForm.queue[0].required = true;
					}else{
						this.disabledInput = false;
						if(this.rulesForm.exchangename.length == 0){
							this.rulesForm.exchangename.push({ required:true, validator:this.validateExchangeName, trigger:'blur'});
						}
						this.form.checked = false;
						this.form.defaultexchange = 'DEFAULTEXCHANGE.0';
						this.routingkey = 'show';
						this.rulesForm.routingkey[0].required = true;
						this.queueClass = 'hide';
						this.rulesForm.queue[0].required = false;
						this.form.queue = "";
					}
					this.hide = 'show';
				}else if(this.form.type == 'EXCHANGETYPE.1'){
					this.hide = 'hide';
					this.routingkey = 'hide';
					this.rulesForm.routingkey[0].required = false;
					this.disabledInput = false;
					if(this.rulesForm.exchangename.length == 0){
						this.rulesForm.exchangename.push({ required:true, validator:this.validateExchangeName, trigger:'blur'});
					}
					this.queueClass = 'hide';
					this.rulesForm.queue[0].required = false;
				}else{
					this.hide = 'hide';
					this.routingkey = 'show';
					this.rulesForm.routingkey[0].required = true;
					this.disabledInput = false;
					if(this.rulesForm.exchangename.length == 0){
						this.rulesForm.exchangename.push({ required:true, validator:this.validateExchangeName, trigger:'blur'});
					}
					this.queueClass = 'hide';
					this.rulesForm.queue[0].required = false;
				}
				this.getAllProductLine();
				this.$store.dispatch('getAppNameList',row.pid).then(val =>{
					this.appNameOptions = val;
				});
			},
			changePridLine(value){
				if(value == ""){
					return false
				}
				this.form.applicationname = "";
				var id;
				for (var item in this.prodLine){
          			if(this.prodLine[item].abbrname == value){
          				id = this.prodLine[item].pid
          			}
          		}
          		this.$store.dispatch('getAppNameList',id).then(val =>{
					this.appNameOptions = val;
				})
			},
			getAppNameId(value){
				if(value == ""){
					return false;
				}
				for (var item in this.appNameOptions){
          			if(this.appNameOptions[item].abbrname == value){
          				this.form.aid = this.appNameOptions[item].aid;
          			}
          		}
			},
			changeExchange(value){
				if(this.form.checked === true){
					this.form.defaultexchange = 'DEFAULTEXCHANGE.1';
					this.disabledInput = true;
					this.rulesForm.exchangename.pop();
					this.form.exchangename = "";
					this.routingkey = 'hide';
					this.rulesForm.routingkey[0].required = false;
					this.form.routingkey = "";
					this.queueClass = 'show';
					this.rulesForm.queue[0].required = true;
				}else{
					this.form.defaultexchange = 'DEFAULTEXCHANGE.0';
					this.disabledInput = false;
					if(this.rulesForm.exchangename.length == 0){
						this.rulesForm.exchangename.push({ required:true, validator:this.validateExchangeName, trigger:'blur'});
					}
					//this.form.exchangename = "";
					this.routingkey = 'show';
					this.rulesForm.routingkey[0].required = true;
					this.queueClass = 'hide';
					this.rulesForm.queue[0].required = false;
					this.form.queue = "";
				}
			},
			validateExchangeName(rule, value, callback){
				if(value === ''){
					callback(new Error('请输入exchange名称'));
				}else{
					var reg = /^[*._/\-|A-Za-z0-9]{1,255}$/;
					if(reg.test(value)){
						callback();
					}else{
						callback(new Error('exchangename只能是数字、字母，不能含有特殊字符且长度不能大于255'));
					}
				}
			},
			changeFormType(value){
				if(value === 'EXCHANGETYPE.0'){
					this.hide = 'show';
					this.routingkey = 'show';
					this.rulesForm.routingkey[0].required = true;
				}else if(value === 'EXCHANGETYPE.1'){
					this.hide = 'hide';
					this.routingkey = 'hide';
					this.rulesForm.routingkey[0].required = false;
					this.form.routingkey = "";
					this.queueClass = 'hide';
					this.rulesForm.queue[0].required = false;
					this.form.queue = "";
					this.disabledInput = false;
					if(this.rulesForm.exchangename.length == 0){
						this.rulesForm.exchangename.push({ required:true, validator:this.validateExchangeName, trigger:'blur'});
					}
				}else{
					this.hide = 'hide';
					this.disabledInput = false;
					if(this.rulesForm.exchangename.length == 0){
						this.rulesForm.exchangename.push({ required:true, validator:this.validateExchangeName, trigger:'blur'});
					}
					this.routingkey = 'show';
					this.rulesForm.routingkey[0].required = true;
					this.queueClass = 'hide';
					this.rulesForm.queue[0].required = false;
					this.form.queue = "";
				}
			},
			submitForm(formName){
				this.$refs[formName].validate((valid) => {
		          if (valid) {
		          	var formData = {
		          		publishid:this.form.publishid,
		          		exchangename:this.form.exchangename,
		          		type:this.form.type,
		          		queue:this.form.queue,
		          		routingkey:this.form.routingkey,
		          		durable:this.form.durable,
		          		autodelete:this.form.autodelete,
		          		internal:this.form.internal,
		          		creater:this.form.creater,
		          		defaultexchange:this.defaultexchange,
		          		aid:this.form.aid
		          	}
		          	this.$store.dispatch('updatePublish',formData).then(val =>{
		          		this.dialogWin = false;
		          		this.$refs[formName].resetFields();
		          		if(val.status == '200'){
		          			this.$message.success(val.data.resMessage);
		          			this.$refs[formName].resetFields();
		          			location.reload();
		          		}else{
		          			this.$message.error(val.data.resMessage);
		          		}
		          	})
		          }else{
		          	return false
		          }
		        })
			},
			resetForm(formName){
		    	this.dialogWin = false;
		    	this.$refs[formName].resetFields();
		    }
		}
	}
</script>
<style scoped lang="scss">
	.checked{
		margin-top:10px;
		padding-left:10px;
	}
	.hide{
		display:none;
	}
	.show{
		display: block;
	}
</style>
