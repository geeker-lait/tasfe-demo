<template>
	<div class="management-wrap">
		<div class="management-bd">
			<el-form :model="form" :rules="rulesForm" ref="form" label-width="140px">
        <el-row>
          <el-col :span="6">
            <el-form-item label="产线："  prop="prodLine">
              <el-select v-model="form.prodLine" @change="changePridLine" filterable>
                <el-option v-for="option in prodLine" :label="option.name" :value="option.abbrname" :key="option.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="应用："  prop="appName" :class="appNameClass">
              <el-select v-model="form.appName" @change="getAppNameId" filterable>
                <el-option v-for="item in appNameOptions" :label="item.name" :value="item.abbrname" :key="item.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
				<el-row>
					<el-col :span="6">
						<el-form-item label="type："  prop="type">
							<el-select v-model="form.type" @change="changeType">
								<el-option label="topic" value="EXCHANGETYPE.3"></el-option>
								<el-option label="fanout" value="EXCHANGETYPE.1"></el-option>
								<!-- <el-option label="headers" value="EXCHANGETYPE.2"></el-option> -->
								<el-option label="direct" value="EXCHANGETYPE.0"></el-option>
							</el-select>
					    </el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="Routing key："  prop="routingkey" :class="routingkeyClass">
					      <el-input v-model="form.routingkey" placeholder="请输入Routing key" auto-complete="off"></el-input>
					    </el-form-item>
					</el-col>
					<el-col :span="6">
						<el-form-item label="queue名称："  prop="queue" :class="queueClass">
					      <el-input v-model="form.queue" placeholder="请输入queue名称" auto-complete="off"></el-input>
					    </el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="19">
						<el-form-item label="Exchange名称："  prop="exchangename" :class="exchangenameClass" :show-message="showMessage">
					    	<el-input v-model="form.exchangename" :disabled="disabledInput" placeholder="请输入exchange名称" auto-complete="off"></el-input>
					    </el-form-item>
					</el-col>
					<el-col :span="4" :class="defaultClass">
						<el-checkbox class="checked" v-model="form.checked" @change="changeExchange">DEFAULTEXCHANGE</el-checkbox>
					</el-col>
				</el-row>

			    <el-row>
					<el-col :span="6">
					    <el-form-item label="是否持久化："  prop="durable">
							<el-select v-model="form.durable">
								<el-option label="是" value="DURABLE.1"></el-option>
								<el-option label="否" value="DURABLE.0"></el-option>
							</el-select>
					    </el-form-item>
					</el-col>
				</el-row>
				 <el-row>
					<el-col :span="6">
					    <el-form-item label="是否自动删除："  prop="autodelete">
							<el-select v-model="form.autodelete">
								<el-option label="是" value="AUTODELETE.1"></el-option>
								<el-option label="否" value="AUTODELETE.0"></el-option>
							</el-select>
					    </el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="6">
					    <el-form-item label="是否internal："  prop="internal">
							<el-select v-model="form.internal">
								<el-option label="是" value="INTERNAL.1"></el-option>
								<el-option label="否" value="INTERNAL.0"></el-option>
							</el-select>
					    </el-form-item>
					</el-col>
				</el-row>
			    <el-row>
					<el-col :span="19">
					    <el-form-item label="创建者："  prop="creater">
					      <el-input v-model="form.creater" placeholder="请输入创建者" auto-complete="off"></el-input>
					    </el-form-item>
					</el-col>
				</el-row>
			    <el-form-item>
			    	<el-button type="primary"  @click="submitForm('form')">申 请</el-button>
					<el-button @click="resetForm('form')">取 消</el-button>
			    </el-form-item>
			</el-form>
		</div>
	</div>
</template>
<script>
	export default{
		data(){
			var validateExchangeName = (rule, value, callback) => {
				if(value === ''){
					callback(new Error('请输入exchange名称'));
				}else{
					var reg = /^[*._/\-|A-Za-z0-9]{1,255}$/;
					if(reg.test(value)){
						callback();
					}else{
						callback(new Error('exchangename只能是数字、字母，不能含有特殊字符且长度不能大于255'));
					}
				}
			};
			var validateCreater = (rule, value, callback) => {
				if(value === ''){
					callback(new Error('请输入creater'));
				}else{
					var reg = /^[\u4e00-\u9fa5/A-Za-z0-9]{1,30}$/;
					if(reg.test(value)){
						callback();
					}else{
						callback(new Error('创建者只能是数字、字母，汉字，不能含有特殊字符且长度不能大于30'));
					}
				}
			};
			return{
				form:{
					exchangename:'',
					prodLine:'',
					appName:'',
					type:'EXCHANGETYPE.0',
					queue:'',
					routingkey:'',
					durable:'DURABLE.1',
					autodelete:'AUTODELETE.0',
					internal:'INTERNAL.0',
					creater:'',
					date:'',
					checked:false,
					aid:'',
				},
				rulesForm:{
					type:[
						{ required:true, message:'请输入exchange名称', trigger:'change'}
					],
					exchangename:[
						{ required:true, validator:validateExchangeName, trigger:'blur'},
					],
					queue:[
						{ required:true, message:'请输入queue名称', trigger:'blur'}
					],
					prodLine:[
						{ required:true, message:'请选择产线', trigger:'change'}
					],
					appName:[
						{ required:true, message:'请选择应用', trigger:'change'}
					],
					routingkey:[
						{ required:true, message:'请输入routingkey', trigger:'blur'}
					],
					creater:[
						{ required:true, validator:validateCreater, trigger:'blur'}
					]
				},
				prodLine:'',
				appNameOptions:[],
				defaultexchange:'DEFAULTEXCHANGE.0',
				disabledInput:false,
				showMessage:true,
				routingkeyClass:'',
				queueClass:'',
				exchangenameClass:'',
				defaultClass:'hide',
				appNameClass:''
			}
		},
		mounted(){
			this.getAllProductLine();
			if(this.form.type == 'EXCHANGETYPE.0'){
				this.defaultClass = 'show';
				this.queueClass = 'hide';
				this.rulesForm.queue[0].required = false;
			}
		},
		methods:{
			validateExchangeName(rule, value, callback){
				if(value === ''){
					callback(new Error('请输入exchange名称'));
				}else{
					var reg = /^[*._/\-|A-Za-z0-9]{1,255}$/;
					if(reg.test(value)){
						callback();
					}else{
						callback(new Error('exchangename只能是数字、字母，不能含有特殊字符且长度不能大于255'));
					}
				}
			},
			changeType(value){
				if(value == 'EXCHANGETYPE.0' ){
					this.defaultClass = 'show';
					this.defaultexchange = 'DEFAULTEXCHANGE.1';
					this.routingkeyClass = 'show';
					this.rulesForm.routingkey[0].required = true;

				}else if(value == 'EXCHANGETYPE.1'){
					//fanout
					this.defaultClass = 'hide';
					this.routingkeyClass = 'hide';
					this.form.routingkey = "";
					this.rulesForm.routingkey[0].required = false;
					this.disabledInput = false;
					if(this.rulesForm.exchangename.length == 0){
						this.rulesForm.exchangename.push({ required:true, validator:this.validateExchangeName, trigger:'blur'});
					}
					this.form.checked = false;
					this.defaultexchange = 'DEFAULTEXCHANGE.0';
					this.showMessage = true;
					this.queueClass = 'hide';
					this.rulesForm.queue[0].required = false;
					this.form.queue = "";
				}else{
					//topic
					this.defaultClass = 'hide';
					this.routingkeyClass = 'show';
					this.rulesForm.routingkey[0].required = true;
					if(this.rulesForm.exchangename.length == 0){
						this.rulesForm.exchangename.push({ required:true, validator:this.validateExchangeName, trigger:'blur'});
					}
					this.disabledInput = false;
					this.form.checked = false;
					this.defaultexchange = 'DEFAULTEXCHANGE.0';
					this.showMessage = true;
					this.queueClass = 'hide';
					this.rulesForm.queue[0].required = false;
					this.form.queue = "";
				}
			},
			changeExchange(value){
				if(this.form.checked === true){
					this.defaultexchange = 'DEFAULTEXCHANGE.1';
					this.disabledInput = true;
					this.rulesForm.exchangename.pop();
					this.form.exchangename = "";
					this.showMessage = false;
					this.routingkeyClass = 'hide';
					this.rulesForm.routingkey[0].required = false;
					this.form.routingkey = ""
					this.queueClass = 'show';
					this.rulesForm.queue[0].required = true;
				}else{
					this.defaultexchange = 'DEFAULTEXCHANGE.0';
					this.disabledInput = false;
					if(this.rulesForm.exchangename.length == 0){
						this.rulesForm.exchangename.push({ required:true, validator:this.validateExchangeName, trigger:'blur'});
					}
					this.form.exchangename = "";
					this.showMessage = true;
					this.routingkeyClass = 'show';
					this.rulesForm.routingkey[0].required = true;
					this.queueClass = 'hide';
					this.rulesForm.queue[0].required = false;
				}
			},
			getAllProductLine(){
				this.$store.dispatch('getAllProdLineList').then(val => {
	  				this.prodLine = val
	  			})
			},
			changePridLine(value){
				if(value == ""){
					return false
				}
				var id;
				for (var item in this.prodLine){
          			if(this.prodLine[item].abbrname == value){
          				id = this.prodLine[item].pid
          			}
          		}
          		this.$store.dispatch('getAppNameList',id).then(val =>{
					this.appNameOptions = val;
				})
			},
			getAppNameId(value){
				if(value == ""){
					return false;
				}
				for (var item in this.appNameOptions){
          			if(this.appNameOptions[item].abbrname == value){
          				this.form.aid = this.appNameOptions[item].aid;
          			}
          		}

			},
			submitForm(formName){
				this.$refs[formName].validate((valid) => {
		          if (valid) {
		          	var formData = {
		          		exchangename:this.form.exchangename,
		          		type:this.form.type,
		          		queue:this.form.queue,
		          		routingkey:this.form.routingkey,
		          		durable:this.form.durable,
		          		autodelete:this.form.autodelete,
		          		internal:this.form.internal,
		          		creater:this.form.creater,
		          		defaultexchange:this.defaultexchange,
		          		aid:this.form.aid,
		          	}
		          	this.$store.dispatch('insertPublish',formData).then(val =>{
		          		if(val.status == '200'){
		          			this.$message.success(val.data.resMessage);
		          			this.$refs[formName].resetFields();
		          			location.href  = '/release-list'
		          		}else{
		          			this.$message.error(val.data.resMessage);
		          		}
		          	})
		          }else{
		          	return false
		          }
		        })
			},
			resetForm(formName){
		    	this.$refs[formName].resetFields();
		    }
		}
	}
</script>
<style lang="scss" scoped>
	.title{
		margin:0;
		color:#48576a;
		font-weight: 400;
		font-size: 16px;
	}
	.hide{
		display: none
	}
	.checked{
		margin-top:10px;
		padding-left:10px;
	}
</style>
