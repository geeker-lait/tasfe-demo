<template>
	<div class="childlist">
		<el-form-item label="产线"  prop="productline">
			<el-select v-model="productline" @change="getAppNameList" filterable>
				<el-option label="所有产线" value=""></el-option>
				<el-option v-for="option in prodLineOptions" :label="option.name" :value="option.abbrname" :key="option.abbrname"></el-option>
			</el-select>
		</el-form-item>
		<el-form-item label="应用"  prop="application" >
			<el-select v-model="application" @change="getAppId" filterable>
				<el-option v-for="item in appNameOptions" :label="item.name" :value="item.abbrname" :key="item.abbrname"></el-option>
			</el-select>
		</el-form-item>
	</div>
</template>
<script>
	export default{
		data(){
			return{

				productline:'',
				application:'',
				pid:'',
				aid:'',
				prodLineOptions:'',
				appNameOptions:''
			}
		},
		mounted(){
			this.getAllProdLineList()
		},
		methods:{
			getAllProdLineList(){
				this.$store.dispatch('getAllProdLineList').then(val =>{
					this.prodLineOptions = val
				})
			},
			getAppNameList(value){
				this.application = "";
				if(value == ""){
					this.productline = "";
					this.pid = ""
				}else{

					for (var item in this.prodLineOptions){
	          			if(this.prodLineOptions[item].abbrname == value){
	          				this.pid = this.prodLineOptions[item].pid
	          			}
	          		}
	          		this.$store.dispatch('getAppNameList',this.pid).then(val =>{
						this.appNameOptions = val;
					})
				}
				var data = {
					productline:this.productline,
					application:this.application,
					pid:this.pid,
					aid:this.aid
				}
		    	this.$emit('ievent',data);

		    },
		    getAppId(value){
		    	if(value == ""){
					return false;
				}
				for (var item in this.appNameOptions){
          			if(this.appNameOptions[item].abbrname == value){
          				this.aid = this.appNameOptions[item].aid;
          			}
          		}
		  		var data = {
					productline:this.productline,
					application:this.application,
					pid:this.pid,
					aid:this.aid
				}
		    	this.$emit('ievent',data);
		    }
		}
	}
</script>
<style>
	.childlist{
		display: inline-block;
		vertical-align: top
	}
</style>
