<template>
  <div class="management-wrap">
    <el-dialog :title="title" :visible.sync="dialogWin" :show-close="false" :close-on-click-modal="false">
      <el-form :model="form" :rules="rulesForm" ref="form" label-width="180px">
        <el-input v-model="form.subscribeid" type="hidden" auto-complete="off"></el-input>
        <el-input v-model="form.aid" type="hidden" auto-complete="off"></el-input>
        <el-row>
          <el-col :span="9">
            <el-form-item label="消费者产线：" prop="consumerproductlinename">
              <el-select v-model="form.consumerproductlinename" @change="changeConsumerPridLine">
                <el-option v-for="option in prodLine" :label="option.name" :value="option.abbrname"
                           :key="option.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="9">
            <el-form-item label="消费者应用：" prop="consumerapplicationname" ref="appName">
              <el-select v-model="form.consumerapplicationname" @change="getConsumerAppNameId">
                <el-option v-for="item in consumerAppNameOptions" :label="item.name" :value="item.abbrname"
                           :key="item.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9">
            <el-form-item label="生产者产线：" prop="productlinename">
              <el-select v-model="form.productlinename" @change="changePridLine">
                <el-option v-for="option in prodLine" :label="option.name" :value="option.abbrname"
                           :key="option.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="9">
            <el-form-item label="生产者应用：" prop="applicationname" ref="appName">
              <el-select v-model="form.applicationname" @change="getAppNameId">
                <el-option v-for="item in appNameOptions" :label="item.name" :value="item.abbrname"
                           :key="item.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9">
            <el-form-item label="待消费Exchagne名称：" prop="exchangename" ref="exchangename" :show-message="showMessage">
              <!--<el-input v-model="form.exchangename" :disabled="disabledInput" placeholder="请输入exchange名称" auto-complete="off"></el-input>-->
              <el-select v-model="form.exchangename" @change="changeExchangeName" :disabled="disabledInput">
                <el-option v-for="option in exchangeArray" :label="option" :value="option" :key="option"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="9">
            <el-checkbox class="checked" v-model="form.checked" @change="changeExchange">DEFAULTEXCHANGE</el-checkbox>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9">
            <el-form-item label="type：" prop="type">
              <el-select v-model="form.type" @change="changeFormType" :disabled="true">
                <el-option label="topic" value="EXCHANGETYPE.3"></el-option>
                <el-option label="fanout" value="EXCHANGETYPE.1"></el-option>
                <!-- <el-option label="headers" value="EXCHANGETYPE.2"></el-option> -->
                <el-option label="direct" value="EXCHANGETYPE.0"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-form-item label="待消费queue名称：" prop="queue" :class="queueClass">
            <el-input v-model="form.queue" placeholder="请输入queue名称" auto-complete="off"></el-input>
            <!--<el-select v-model="form.queue">-->
            <!--<el-option v-for="option in queueArray" :label="option" :value="option" :key="option"></el-option>-->
            <!--</el-select>-->
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="binding key：" prop="routingkey" :class="routingkeyClass">
            <el-input v-model="form.routingkey" placeholder="请输入binding key" auto-complete="off"></el-input>
          </el-form-item>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="autoack：">
              <el-select v-model="form.autoack">
                <el-option label="是" value="AUTOACK.1"></el-option>
                <el-option label="否" value="AUTOACK.0"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10">
            <el-tooltip class="item" effect="light"
                        content="消费者消费消息后发送回执给server端（异步），server端根据回执决定是否自动从队列中删除。默认为false，不删除。" placement="right">
              <i class="el-icon-information" style="color:#48ace6;margin:10px 0 0 10px;"></i>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="fetchcount：" prop="fetchcount">
              <el-input v-model="form.fetchcount" placeholder="请输入批处理消息数" auto-complete="off"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10">
            <el-tooltip class="item" effect="light" content="消费者每批次从queue中获取的消息数" placement="right">
              <i class="el-icon-information" style="color:#48ace6;margin:10px 0 0 10px;"></i>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="threadnum：" prop="threadnum">
              <el-input v-model="form.threadnum" placeholder="请输入并发线程数" auto-complete="off"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10">
            <el-tooltip class="item" effect="light" content="消费者同时处理queue的线程数" placement="right">
              <i class="el-icon-information" style="color:#48ace6;margin:10px 0 0 10px;"></i>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-form-item label="创建者：" prop="creater">
          <el-input v-model="form.creater" placeholder="请输入创建者" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="描述：" prop="desc">
          <el-input v-model="form.desc" type="textarea" placeholder="该描述用于描述消费者用途，断开消费者连接时根据该描述区分"
                    auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="text" @click="resetForm('form')">取 消</el-button>
        <el-button type="primary" @click="submitForm('form')">提 交</el-button>
      </div>
    </el-dialog>
    <div class="management-hd">
      <el-form :model="searchForm" :inline="true" label="90px">
        <proLineApp @ievent="ievent"></proLineApp>
        <el-button type="primary" @click="filterList" icon="search">搜索</el-button>
      </el-form>
    </div>
    <div class="management-bd">
      <el-table :data="listPage" border>
        <el-table-column prop="consumerproductlinename" label="消费者产线"></el-table-column>
        <el-table-column prop="consumerapplicationname" label="消费者应用"></el-table-column>
        <el-table-column prop="productlinename" label="生产者产线"></el-table-column>
        <el-table-column prop="applicationname" label="生产者应用"></el-table-column>
        <el-table-column prop="exchangename" label="待消费Exchange名称"></el-table-column>
        <el-table-column prop="typename" label="type" width="80"></el-table-column>
        <el-table-column prop="queue" label="待消费queue名称"></el-table-column>
        <el-table-column prop="routingkey" label="Binding key"></el-table-column>
        <el-table-column prop="autoackname" label="是否自动从队列中删除" width="120"></el-table-column>
        <el-table-column prop="fetchcount" label="批处理消息数" width="120"></el-table-column>
        <el-table-column prop="threadnum" label="并发线程数" width="120"></el-table-column>
        <el-table-column prop="creater" label="创建人" width="120"></el-table-column>
        <el-table-column prop="desc" label="描述"></el-table-column>
        <el-table-column prop="birthtime" label="创建时间" width="180"></el-table-column>
        <el-table-column prop="checkstatusname" label="审核状态" width="120"></el-table-column>
        <el-table-column label="操作" width="80">
          <template scope="scope">
            <el-button type="text" size="small" @click="update(scope.row)"
                       v-if='scope.row.checkstatus != "CHECKSTATUS.1"'>修改
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="management-ft">
      <el-pagination @current-change="currentChange" :current-page.sync="firstPage" layout="total,prev, pager, next"
                     :page-size="pageSize" :total="totalSize" v-if="totalSize > 0">
      </el-pagination>
    </div>
  </div>
</template>
<script>
  import proLineApp from '../prodlineapp'
  export default{
    data(){
      var validateExchangeName = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入exchange名称'));
        } else {
          var reg = /^[*._/\-|A-Za-z0-9]{1,255}$/;
          if (reg.test(value)) {
            callback();
          } else {
            callback(new Error('exchangename只能是数字、字母，不能含有特殊字符且长度不能大于255'));
          }
        }
      };
      var validateCreater = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入creater'));
        } else {
          var reg = /^[\u4e00-\u9fa5/A-Za-z0-9]{1,30}$/;
          if (reg.test(value)) {
            callback();
          } else {
            callback(new Error('创建者只能是数字、字母，汉字，不能含有特殊字符且长度不能大于30'));
          }
        }
      };
      var validatefetchcount = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入fetchcount'));
        } else {
          var reg = /[1-9][0-9]*$/;
          if (reg.test(value) && value.indexOf(".") < 0 && value < 10000) {
            callback();
          } else {
            callback(new Error('fetchout只能为数字,且大于0小于10000'));
          }
        }
      };
      var validatethreadnum = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入threadnum'));
        } else {
          var reg = /[1-9][0-9]*$/;
          if (reg.test(value) && value.indexOf(".") < 0 && value < 10000) {
            callback();
          } else {
            callback(new Error('threadnum只能为数字,且大于0小于10000'));
          }
        }
      };
      return {
        firstPage: 1,
        pageSize: 10,
        totalSize: '',
        list: [],
        listPage: [],
        dialogWin: false,
        title: '修改Exchange',
        disabledInput: false,
        routingkeyClass: '',
        queueClass: '',
        defaultClass: 'hide',
        infoArray: [],
        exchangeArray: [],
        queueArray: [],
        defaultQueueArray: [],
        form: {
          type: '',
          routingkey: '',
          queue: '',
          exchangename: '',
          checked: '',
          productlinename: '',
          applicationname: '',
          consumerProductlinename: '',
          consumerApplicationname: '',
          creater: '',
          subscribeid: '',
          aid: '',
          defaultexchange: '',
          autoack: 'AUTOACK.0',
          fetchcount: '',
          threadnum: ''
        },
        rulesForm: {
          type: [
            {required: true, message: '请输入exchange名称', trigger: 'change'}
          ],
          exchangename: [
            {required: true, validator: validateExchangeName, trigger: 'blur'}
          ],
          queue: [
            {required: true, message: '请输入queue名称', trigger: 'blur'}
          ],
          productlinename: [
            {required: true, message: '请选择生产者产线', trigger: 'change'}
          ],
          applicationname: [
            {required: true, message: '请选择生产者应用', trigger: 'change'}
          ],
          consumerproductlinename: [
            {required: true, message: '请选择消费者产线', trigger: 'change'}
          ],
          consumerapplicationname: [
            {required: true, message: '请选择消费者应用', trigger: 'change'}
          ],
          routingkey: [
            {required: true, message: '请输入routingkey', trigger: 'blur'}
          ],
          creater: [
            {required: true, validator: validateCreater, trigger: 'blur'}
          ],
          desc: [
            {required: true, message: '请输入描述', trigger: 'blur'}
          ]
        },
        prodLine: '',
        appNameOptions: '',
        consumerAppNameOptions: '',
        showMessage: true,
        searchForm: {
          prodLine: '',
          appName: '',
          pid: '',
          aid: ''
        }
      }
    },
    components: {
      proLineApp
    },
    mounted(){
      this.getAllSubscribe();
    },
    methods: {
      ievent(...data){
        this.searchForm.prodLine = data[0].productline;
        this.searchForm.appName = data[0].application;
        this.searchForm.pid = data[0].pid;
        this.searchForm.aid = data[0].aid;
      },
      filterList(){
        if (this.searchForm.prodLine == "") {
          this.getAllSubscribe();
        } else {
          var str = {
            pid: this.searchForm.pid,
            aid: this.searchForm.appName == "" ? 0 : this.searchForm.aid
          };
          this.$store.dispatch('getByProductLine', str).then(val => {
            this.list = val;
            this.totalSize = val.length;
            if (this.totalSize <= this.pageSize) {
              this.listPage = this.list.slice('0', this.list.length)
            } else {
              this.listPage = this.list.slice('0', this.pageSize)
            }
          });
        }
      },
      getAllSubscribe(){
        this.$store.dispatch('getAllSubscribe').then(val => {
          for (var item in val) {
            var time = val[item].birthtime.slice(0, val[item].birthtime.length - 2);
            val[item].birthtime = time
          }
          this.list = val;
          this.totalSize = val.length;
          if (this.totalSize <= this.pageSize) {
            this.listPage = this.list.slice('0', this.list.length)
          } else {
            this.listPage = this.list.slice('0', this.pageSize)
          }
        })
      },
      currentChange(val){
        this.listPage = this.list.slice((val - 1) * this.pageSize, (val - 1) * this.pageSize + this.pageSize);
      },
      changeFormType(value){
        if (value === 'EXCHANGETYPE.0') {
          this.defaultClass = 'show';
          this.routingkeyClass = 'show';
          this.rulesForm.routingkey[0].required = true;
        } else if (value === 'EXCHANGETYPE.1') {
          this.defaultClass = 'show';
          this.routingkeyClass = 'hide';
          this.rulesForm.routingkey[0].required = false;
          this.form.routingkey = ""
        } else {
          this.defaultClass = 'show';
          this.disabledInput = false;
          this.rulesForm.exchangename[0].required = true;
          this.routingkeyClass = 'show';
          this.rulesForm.routingkey[0].required = true;
        }
      },
      changeExchange(){
        if (this.form.checked == true) {
          this.form.exchangename = "";
          this.form.routingkey = "";
          this.defaultexchange = 'DEFAULTEXCHANGE.1';
          this.disabledInput = true;
          this.rulesForm.exchangename[0] = {trigger: 'blur'};
          this.showMessage = false;
          this.rulesForm.routingkey[0] = {trigger: 'blur'};
          this.queueArray = this.defaultQueueArray;
          this.routingkeyClass = 'hide';
          this.form.type = 'EXCHANGETYPE.0';
        } else {
          this.routingkeyClass = 'show';
          this.defaultexchange = 'DEFAULTEXCHANGE.0';
          this.disabledInput = false;
          this.rulesForm.exchangename[0] = {required: true, trigger: 'blur'};
          this.form.exchangename = "";
          this.showMessage = true;
          this.rulesForm.routingkey[0] = {required: true, message: '请输入bindingkey', trigger: 'blur'};
          this.form.queue = "";
        }
      },
      changePridLine(value){
        this.form.appName = '';
        if (value == "") {
          return false
        }
        this.form.applicationname = "";
        var id;
        for (var item in this.prodLine) {
          if (this.prodLine[item].abbrname == value) {
            id = this.prodLine[item].pid
          }
        }
        this.$store.dispatch('getAppNameList', id).then(val => {
          this.appNameOptions = val;
        })
      },
      changeConsumerPridLine(value)
      {
        this.form.consumerapplicationname = '';
        if (value == "") {
          return false
        }
        var id;
        for (var item in this.prodLine) {
          if (this.prodLine[item].abbrname == value) {
            id = this.prodLine[item].pid
          }
        }
        this.$store.dispatch('getAppNameList', id).then(val => {
          this.consumerAppNameOptions = val;
        })
      },
      getAppNameId(value){
        this.form.exchangename = "";
        this.form.checked = false;
        this.disabledInput = false;
        if (value == "") {
          return false;
        }
        for (var item in this.appNameOptions) {
          if (this.appNameOptions[item].abbrname == value) {
            this.form.aid = this.appNameOptions[item].aid;
          }
        }
        var str = {"applicationid": this.form.aid};
        this.$store.dispatch('getByProductLineOrApplicationId', str).then(val => {
          this.infoArray = [];
          for (let i = 0; i < val.length; i++) {
            if (val[i].checkstatus == 'CHECKSTATUS.1') {
              this.infoArray.push(val[i]);
            }
          }
          this.exchangeArray = [];
          for (let i = 0; i < this.infoArray.length; i++) {
            if (this.exchangeArray.indexOf(this.infoArray[i].exchangename) == -1 && this.infoArray[i].exchangename != "") {
              this.exchangeArray.push(this.infoArray[i].exchangename);
            }
          }
          this.defaultQueueArray = [];
          for (let i = 0; i < this.infoArray.length; i++) {
            if (this.infoArray[i].exchangename == "") {
              this.defaultQueueArray.push(this.infoArray[i].queue);
            }
          }
        })
      },
      getConsumerAppNameId(value){
        for (var item in this.consumerAppNameOptions) {
          if (this.consumerAppNameOptions[item].abbrname == value) {
            this.form.consumeraid = this.consumerAppNameOptions[item].aid;
          }
        }
      },
      getAllProductLines(){
        this.$store.dispatch('getAllProdLineList').then(val => {
          this.prodLine = val
        })
      },
      update(row){
        this.dialogWin = true;
        this.form = {
          type: row.type,
          routingkey: row.routingkey,
          queue: row.queue,
          exchangename: row.exchangename,
          productlinename: row.productlineabbrname,
          applicationname: row.applicationabbrname,
          consumerproductlinename: row.consumerproductlineabbrname,
          consumerapplicationname: row.consumerapplicationabbrname,
          creater: row.creater,
          subscribeid: row.subscribeid,
          defaultexchange: row.defaultexchange,
          desc: row.desc,
          aid: row.aid,
          consumeraid: row.consumeraid,
          autoack: row.autoack,
          fetchcount: row.fetchcount,
          threadnum: row.threadnum
        };

        if (this.form.type == 'EXCHANGETYPE.0') {
          if (this.form.exchangename == "") {
            this.disabledInput = true;
            this.rulesForm.exchangename[0] = {trigger: 'blur'};
            this.routingkeyClass = 'hide';
            this.rulesForm.routingkey[0] = {trigger: 'blur'};
            this.form.checked = true;
            this.form.defaultexchange = 'DEFAULTEXCHANGE.1'
          } else {
            this.disabledInput = false;
            this.rulesForm.exchangename[0] = {required: true, trigger: 'blur'};
            this.form.checked = false;
            this.form.defaultexchange = 'DEFAULTEXCHANGE.0';
            this.routingkeyClass = 'show';
            this.rulesForm.routingkey[0] = {required: true, message: '请输入bindingkey', trigger: 'blur'};
          }
          this.defaultClass = 'show';
        } else if (this.form.type == 'EXCHANGETYPE.1') {
          this.defaultClass = 'hide';
          this.routingkeyClass = 'hide';
          this.rulesForm.routingkey[0] = {trigger: 'blur'};
          this.disabledInput = false;
          this.rulesForm.exchangename[0] = {trigger: 'blur'};
        } else {
          this.defaultClass = 'hide';
          this.routingkeyClass = 'show';
          this.rulesForm.routingkey[0] = {required: true, message: '请输入bindingkey', trigger: 'blur'};
          this.disabledInput = false;
          this.rulesForm.exchangename[0] = {required: true, trigger: 'blur'};
        }
        this.getAllProductLines();
        this.$store.dispatch('getAppNameList', row.pid).then(val => {
          this.appNameOptions = val;
        });
        this.$store.dispatch('getAppNameList', row.consumerpid).then(val => {
          this.consumerAppNameOptions = val;
        });
        //加载当前应用的exchangename到下拉框中
        var str = {"applicationid": this.form.aid};
        this.$store.dispatch('getByProductLineOrApplicationId', str).then(val => {
          this.infoArray = [];
          for (let i = 0; i < val.length; i++) {
            if (val[i].checkstatus == 'CHECKSTATUS.1') {
              this.infoArray.push(val[i]);
            }
          }
          this.exchangeArray = [];
          for (let i = 0; i < this.infoArray.length; i++) {
            if (this.exchangeArray.indexOf(this.infoArray[i].exchangename) == -1 && this.infoArray[i].exchangename != "") {
              this.exchangeArray.push(this.infoArray[i].exchangename);
            }
          }
          this.defaultQueueArray = [];
          for (let i = 0; i < this.infoArray.length; i++) {
            if (this.infoArray[i].exchangename == "") {
              this.defaultQueueArray.push(this.infoArray[i].queue);
            }
          }
        });

      },
      submitForm(formName){
        this.$refs[formName].validate((valid) => {
          if (valid) {
            var formData = {
              subscribeid: this.form.subscribeid,
              exchangename: this.form.exchangename,
              type: this.form.type,
              queue: this.form.queue,
              routingkey: this.form.routingkey,
              creater: this.form.creater,
              defaultexchange: this.form.defaultexchange,
              aid: this.form.aid,
              consumeraid: this.form.consumeraid,
              desc: this.form.desc,
              autoack: this.form.autoack,
              fetchcount: this.form.fetchcount,
              threadnum: this.form.threadnum
            }
            this.$store.dispatch('updateSubscribe', formData).then(val => {
              this.dialogWin = false;
              this.$refs[formName].resetFields();
              if (val.status == '200') {
                this.$message.success(val.message);
                this.$refs[formName].resetFields();
                location.reload();
              } else {
                this.$message.error(val.message);
              }
            })
          } else {
            return false
          }
        })
      },
      changeExchangeName(){
        this.form.queue = "";
        this.queueArray = [];
        for (var i = 0; i < this.infoArray.length; i++) {
          if (this.form.exchangename == this.infoArray[i].exchangename) {
            this.form.type = this.infoArray[i].type;
            this.changeType(this.form.type);
            this.queueArray.push(this.infoArray[i].queue);
          }
        }
      },
      changeType(value){
        if (value === 'EXCHANGETYPE.3') {
          this.defaultClass = 'show';
          this.disabledInput = false;
          this.rulesForm.exchangename[0].required = true;
          this.routingkeyClass = 'show';
          this.rulesForm.routingkey[0].required = true;

        } else if (value === 'EXCHANGETYPE.1') {
          this.defaultClass = 'show';
          this.disabledInput = false;
          this.rulesForm.exchangename[0].required = true;
          this.routingkeyClass = 'hide';
          this.form.routingkey = "";
          this.rulesForm.routingkey[0].required = false;
        } else {
          this.defaultClass = 'show';
          if (this.form.checked) {
            this.routingkeyClass = 'hide';
          } else {
            this.routingkeyClass = 'show';
          }
          this.rulesForm.routingkey[0].required = true;
        }
      },
      getAllProductLines(){
        this.$store.dispatch('getAllProdLineList').then(val => {
          this.prodLine = val
        })
      },
      resetForm(formName){
        this.dialogWin = false;
        this.$refs[formName].resetFields();
      }
    }
  }
</script>
<style lang="scss" scoped>
  .hide {
    display: none
  }

  .show {
    display: block
  }

  .checked {
    margin-top: 10px;
    padding-left: 10px;
  }
</style>
