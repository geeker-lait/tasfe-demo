<template>
	<div class="management-wrap">
		<el-dialog :title="title" :visible.sync="dialogWin" size="large" :show-close="true"  :close-on-click-modal="false">
			<el-table :data="channelsList" border>
				<el-table-column prop="productline" label="产线"></el-table-column>
				<el-table-column prop="application" label="应用"></el-table-column>
				<el-table-column prop="name" label="channel" width="200"></el-table-column>
				<el-table-column prop="channelnumber" label="channelnumber" width="90"></el-table-column>
				<el-table-column prop="defaultexchangename" label="defaultexchange"></el-table-column>
				<el-table-column prop="exchangename" label="exchange" width="120"></el-table-column>
				<el-table-column prop="ip" label="ip"></el-table-column>
				<el-table-column prop="port" label="port" width="80"></el-table-column>
				<el-table-column prop="typename" label="type"></el-table-column>
				<el-table-column prop="queue" label="queue"></el-table-column>
				<el-table-column prop="routingkey" label="bindingkey" width="120"></el-table-column>
				<el-table-column prop="desc" label="描述"></el-table-column>
				<el-table-column prop="state" label="state"></el-table-column>
				<el-table-column prop="runstatusname" label="状态"></el-table-column>
				<el-table-column label="操作">
			      <template scope="scope">
			        <el-button type="text" size="small" v-if='scope.row.runstatus == "RUNSTATUS.1"' @click="running(scope.row)">断开</el-button>
			        <el-button type="text" size="small" v-if='scope.row.runstatus == "RUNSTATUS.0"' @click="running(scope.row)">连接</el-button>
			      </template>
			    </el-table-column>
			</el-table>
		</el-dialog>
		<div class="management-hd">
			
			<el-form :model="searchForm" :inline="true" label="90px">
				<proLineApp @ievent = "ievent"></proLineApp>
				<el-button type="primary" @click="filterList"  icon="search">搜索</el-button>
			</el-form>
		</div>
		<div class="management-bd">
			<el-table :data="listPage" border>
				<el-table-column prop="productline" label="产线"></el-table-column>
				<el-table-column prop="application" label="应用"></el-table-column>
				<el-table-column prop="name" label="collection" width="300"></el-table-column>
				<el-table-column prop="channels" label="channels数"></el-table-column>
				<el-table-column prop="vhost" label="vhost"></el-table-column>
				<el-table-column prop="state" label="状态"></el-table-column>
				<el-table-column label="操作">
			      <template scope="scope">
			        <el-button type="text" size="small" @click="getChannelsList(scope.row)">查看channel</el-button>
			      </template>
			    </el-table-column>
			</el-table>
		</div>
		<div class="management-ft">
			<el-pagination @current-change="currentChange" :current-page.sync="firstPage" layout="total,prev, pager, next" :page-size="pageSize" :total="totalSize" v-if="totalSize > 0">
			</el-pagination>
		</div>
	</div>
</template>
<script>
	import proLineApp from '../prodlineapp'
	export default{
		data(){
			return{
				searchForm:{
					productline:'',
					application:''
				},
				title:'channel列表',
				dialogWin:false,
				firstPage:1,
				pageSize:10,
				totalSize:'',
				list:[],
				listPage:[],
				channelsList:[],
				prodLineOptions:'',
				appNameOptions:''
			}
		},
		components:{
			proLineApp
		},

		mounted(){
			this.getCollections();
		},
		methods:{
			ievent(...data){
				this.searchForm.productline = data[0].productline;
				this.searchForm.application = data[0].application
			},
			filterList(){
				this.getCollections()
			},
			getCollections(){
				var str = {
					productline:this.searchForm.productline,
					application:this.searchForm.application
				}
				this.$store.dispatch('getCollections',str).then(val =>{
					this.list = val;
					this.totalSize = val.length;
					if(this.totalSize <= this.pageSize){
	  					this.listPage = this.list.slice('0',this.list.length)
	  				}else{
	  					this.listPage = this.list.slice('0',this.pageSize)
	  				}
				})
			},
			currentChange(val){
		    	this.listPage = this.list.slice((val - 1)*this.pageSize,(val - 1)*this.pageSize+this.pageSize);
		    },
		    getChannelsList(row){
		    	this.dialogWin = true;
		    	var name = row.name;
		    	this.$store.dispatch('getChannels',name).then(val =>{
		    		this.channelsList = val;
		    	})
		    },
		    running(row){
		    	console.log(row)
		    	var data = {
		    		channelid : row.channelid,
		    		runstatus : row.runstatus == 'RUNSTATUS.1'?'RUNSTATUS.0':'RUNSTATUS.1',
		    		productline:row.productline,
		    		application:row.application,
		    		ip:row.ip,
		    		port:row.port
		    	}

		    	this.$store.dispatch('runStatus',data).then(val =>{
		    		if(val.status == '200'){
		    			if(row.runstatus == 'RUNSTATUS.1'){
		    				row.runstatus = 'RUNSTATUS.0';
		    				row.runstatusname = '断开';
		    			}else{
		    				row.runstatus = 'RUNSTATUS.1';
		    				row.runstatusname = '连接';
		    			}
		    		}
		    	})
		    }
		}
	}
</script>
<style lang="scss">
	.el-table .el-table__header  th>.cell{
	 	line-height: 1 !important;
	}
</style>