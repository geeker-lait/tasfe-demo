<template>
	<div class="management-wrap">
		<div class="management-hd">
			<el-form :model="searchForm" :inline="true" label="90px">
				<proLineApp @ievent = "ievent"></proLineApp>
				<el-button type="primary" @click="filterList"  icon="search">搜索</el-button>
			</el-form>
		</div>
		<div class="management-bd">
			<el-table :data="listPage" border>
        <el-table-column prop="consumerproductlinename" label="消费者产线"></el-table-column>
        <el-table-column prop="consumerapplicationname" label="消费者应用"></el-table-column>
        <el-table-column prop="productlinename" label="生产者产线"></el-table-column>
        <el-table-column prop="applicationname" label="生产者应用"></el-table-column>
				<el-table-column prop="exchangename" label="待消费Exchange名称"></el-table-column>
				<el-table-column prop="typename" label="type" width="70"></el-table-column>
				<el-table-column prop="queue" label="待消费queue名称"></el-table-column>
				<el-table-column prop="routingkey" label="Binding key"></el-table-column>
        <el-table-column prop="autoackname" label="是否自动从队列中删除" width="120"></el-table-column>
        <el-table-column prop="fetchcount" label="批处理消息数" width="120"></el-table-column>
        <el-table-column prop="threadnum" label="并发线程数" width="120"></el-table-column>
				<el-table-column prop="creater" label="创建人"  width="100"></el-table-column>
				<el-table-column prop="desc" label="描述"></el-table-column>
				<el-table-column prop="birthtime" label="创建时间" width="150"></el-table-column>
				<el-table-column prop="checkstatusname" label="审核状态" width="100"></el-table-column>
				<el-table-column label="操作">
			      <template scope="scope">
			      	<template v-if='scope.row.checkstatus == "CHECKSTATUS.0"'>
						<el-button type="text" size="small" @click="checkstatusYes(scope.row)">通过</el-button>
						<el-button type="text" size="small" @click="checkstatusNo(scope.row)">不通过</el-button>
			      	</template>
			      	<template v-if='scope.row.checkstatus == "CHECKSTATUS.1"'>
			      		<el-button type="text" size="small" @click="checkstatusNo(scope.row)">不通过</el-button>
			      	</template>
			        <el-button type="text" size="small" @click="deleteRow(scope.row,scope.$index)">删除</el-button>
			      </template>
			    </el-table-column>
			</el-table>
		</div>
		<div class="management-ft">
			<el-pagination @current-change="currentChange" :current-page.sync="firstPage" layout="total,prev, pager, next" :page-size="pageSize" :total="totalSize" v-if="totalSize > 0">
			</el-pagination>
		</div>
	</div>
</template>
<script>
	import proLineApp from '../prodlineapp'
	export default{
		data(){
			return{
				firstPage:1,
				pageSize:10,
				totalSize:'',
				searchForm:{
					prodLine:'',
					appName:'',
					pid:'',
					aid:''
				},
				list:[],
				listPage:[],
				prodLineOptions:'',
				appNameOptions:''
			}
		},
		components:{
			proLineApp
		},
		mounted(){
			this.getAllSubscribe();
			//this.getAllProdLine();
		},
		methods:{
			ievent(...data){
				this.searchForm.prodLine = data[0].productline;
				this.searchForm.appName = data[0].application;
				this.searchForm.pid = data[0].pid;
				this.searchForm.aid = data[0].aid;
			},
			// getAllProdLine(){
			// 	this.$store.dispatch('getAllProductLines').then(val =>{
			// 		this.prodLineOptions = val
			// 	})
			// },
			// getAppNameList(value){
			// 	if(value == ""){
			// 		return false
			// 	}
			// 	this.searchForm.appName = "";
			// 	for (var item in this.prodLineOptions){
   //        			if(this.prodLineOptions[item].abbrname == value){
   //        				this.searchForm.pid = this.prodLineOptions[item].pid
   //        			}
   //        		}
   //        		this.$store.dispatch('getAppNameList',this.searchForm.pid).then(val =>{
			// 		this.appNameOptions = val;
			// 	})
			// },
			// getAppId(value){
			// 	if(value == ""){
			// 		return false;
			// 	}
			// 	for (var item in this.appNameOptions){
   //        			if(this.appNameOptions[item].abbrname == value){
   //        				this.searchForm.aid = this.appNameOptions[item].aid;
   //        			}
   //        		}
			// },
			filterList(){
				if(this.searchForm.prodLine == ""){
					this.getAllSubscribe();
				}else{
					var str = {
						pid:this.searchForm.pid,
						aid:this.searchForm.appName == ""?0:this.searchForm.aid
					}
					this.$store.dispatch('getByProductLine',str).then(val =>{
						this.list = val;
						this.totalSize = val.length;
						if(this.totalSize <= this.pageSize){
		  					this.listPage = this.list.slice('0',this.list.length)
		  				}else{
		  					this.listPage = this.list.slice('0',this.pageSize)
		  				}
					})
				}
			},
			getAllSubscribe(){
				this.$store.dispatch('getAllSubscribe').then(val =>{
					for(var item in val){
						var time = val[item].birthtime.slice(0,val[item].birthtime.length-2);
						val[item].birthtime = time
					}
					this.list = val;
					this.totalSize = val.length;
					if(val <= this.pageSize){
	  					this.listPage = this.list.slice('0',this.list.length)
	  				}else{
	  					this.listPage = this.list.slice('0',this.pageSize)
	  				}
				})
			},
			currentChange(val){
		    	this.listPage = this.list.slice((val - 1)*this.pageSize,(val - 1)*this.pageSize+this.pageSize);
		    },
		    deleteRow(row,index){
				this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
		          confirmButtonText: '确定',
		          cancelButtonText: '取消',
		          type: 'warning'
		        }).then(() => {
			    	var subscribeid = row.subscribeid;
			    	this.$store.dispatch('deleteSubscribe',subscribeid).then(val => {
			    		if(val.status == '200'){
							this.$message.success(val.message);
	  						this.listPage.splice(index,1);
	  						this.totalSize = this.totalSize - 1;
						}else{
							this.$message.error(val.message);
						}
			    	})
			    }).catch(() => {
		          this.$message({
		            type: 'info',
		            message: '已取消删除'
		          });
		        });
			},
			checkstatusYes(row){
		    	var status = 'CHECKSTATUS.1';
		    	var subscribeid = row.subscribeid;
		    	var str = {
		    		subscribeid:subscribeid,
		    		checkstatus:status
		    	}
		    	this.$store.dispatch('checkSubscribe',str).then(val =>{
		    		if(val.status == '200'){
		    			this.$message.success(val.message);
		    			row.checkstatusname = '审核通过';
		    			row.checkstatus = 'CHECKSTATUS.1'
		    			//location.reload();
		    		}else{
		    			this.$message.error(val.message);
		    		}
		    	})
		    },
		    checkstatusNo(row){
		    	var status = 'CHECKSTATUS.2';
		    	var subscribeid = row.subscribeid;
		    	var str = {
		    		subscribeid:subscribeid,
		    		checkstatus:status
		    	}
		    	this.$store.dispatch('checkSubscribe',str).then(val =>{
		    		if(val.status == '200'){
		    			this.$message.success(val.message);
		    			row.checkstatusname = '审核未通过';
		    			row.checkstatus = 'CHECKSTATUS.2'
		    			//location.reload();
		    		}else{
		    			this.$message.error(val.message);
		    		}
		    	})
		    }
		}
	}
</script>
