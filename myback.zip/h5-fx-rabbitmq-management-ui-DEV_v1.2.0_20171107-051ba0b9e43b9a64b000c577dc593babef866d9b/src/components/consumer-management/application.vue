<template>
  <div class="management-wrap">
    <div class="management-bd">
      <el-form :model="form" :rules="rulesForm" ref="form" label-width="180px">
        <el-row>
          <el-col :span="6">
            <el-form-item label="消费者产线：" prop="consumerProdLine">
              <el-select v-model="form.consumerProdLine" @change="changeConsumerPridLine" filterable>
                <el-option v-for="option in prodLine" :label="option.name" :value="option.abbrname"
                           :key="option.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="7">
            <el-form-item label="消费者应用：" prop="consumerAppName" ref="appName">
              <el-select v-model="form.consumerAppName" @change="getConsumerAppNameId" filterable>
                <el-option v-for="item in consumerAppNameOptions" :label="item.name" :value="item.abbrname"
                           :key="item.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="生产者产线：" prop="prodLine">
              <el-select v-model="form.prodLine" @change="changePridLine" filterable>
                <el-option v-for="option in prodLine" :label="option.name" :value="option.abbrname"
                           :key="option.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="7">
            <el-form-item label="生产者应用：" prop="appName" ref="appName">
              <el-select v-model="form.appName" @change="getAppNameId" filterable>
                <el-option v-for="item in appNameOptions" :label="item.name" :value="item.abbrname"
                           :key="item.abbrname"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="待消费Exchagne名称：" prop="exchangename" ref="exchangename" :show-message="showMessage">
              <!--<el-input v-model="form.exchangename" :disabled="disabledInput" placeholder="请输入exchange名称"-->
              <!--auto-complete="off"></el-input>-->
              <el-select v-model="form.exchangename" @change="changeExchangeName" :disabled="disabledInput">
                <el-option v-for="option in exchangeArray" :label="option" :value="option" :key="option"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4" :class="defaultClass">
            <el-checkbox class="checked" v-model="form.checked" @change="changeExchange">DEFAULTEXCHANGE</el-checkbox>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="type：" prop="type">
              <el-select v-model="form.type" :disabled="true">
                <el-option label="topic" value="EXCHANGETYPE.3"></el-option>
                <el-option label="fanout" value="EXCHANGETYPE.1"></el-option>
                <!-- <el-option label="headers" value="EXCHANGETYPE.2"></el-option> -->
                <el-option label="direct" value="EXCHANGETYPE.0"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="待消费queue名称：" prop="queue" :class="queueClass">
              <el-input v-model="form.queue" placeholder="请输入queue名称" auto-complete="off"></el-input>
              <!--<el-select v-model="form.queue">-->
              <!--<el-option v-for="option in queueArray" :label="option" :value="option" :key="option"></el-option>-->
              <!--</el-select>-->
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="binding key：" prop="routingkey" :class="routingkeyClass">
              <el-input v-model="form.routingkey" placeholder="请输入binding key" auto-complete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="autoack：">
              <el-select v-model="form.autoack">
                <el-option label="是" value="AUTOACK.1"></el-option>
                <el-option label="否" value="AUTOACK.0"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-tooltip class="item" effect="light"
                        content="消费者消费消息后发送回执给server端（异步），server端根据回执决定是否自动从队列中删除。默认为false，不删除。" placement="right">
              <i class="el-icon-information" style="color:#48ace6;margin:10px 0 0 10px;"></i>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="fetchcount：" prop="fetchcount">
              <el-input v-model="form.fetchcount" placeholder="请输入批处理消息数" auto-complete="off"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-tooltip class="item" effect="light" content="消费者每批次从queue中获取的消息数" placement="right">
              <i class="el-icon-information" style="color:#48ace6;margin:10px 0 0 10px;"></i>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="threadnum：" prop="threadnum">
              <el-input v-model="form.threadnum" placeholder="请输入并发线程数" auto-complete="off"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-tooltip class="item" effect="light" content="消费者同时处理queue的线程数" placement="right">
              <i class="el-icon-information" style="color:#48ace6;margin:10px 0 0 10px;"></i>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="19">
            <el-form-item label="创建者：" prop="creater">
              <el-input v-model="form.creater" placeholder="请输入创建者" auto-complete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="描述：" prop="desc">
          <el-input v-model="form.desc" type="textarea" placeholder="该描述用于描述消费者用途，断开消费者连接时根据该描述区分"
                    auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm('form')">申 请</el-button>
          <el-button @click="resetForm('form')">取 消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
  export default{
    data(){
      var validateExchangeName = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入exchange名称'));
        } else {
          var reg = /^[*._/\-|A-Za-z0-9]{1,255}$/;
          if (reg.test(value)) {
            callback();
          } else {
            callback(new Error('exchangename只能是数字、字母，不能含有特殊字符且长度不能大于255'));
          }
        }
      };
      var validateCreater = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入creater'));
        } else {
          var reg = /^[\u4e00-\u9fa5/A-Za-z0-9]{1,30}$/;
          if (reg.test(value)) {
            callback();
          } else {
            callback(new Error('创建者只能是数字、字母，汉字，不能含有特殊字符且长度不能大于30'));
          }
        }
      };
      var validatefetchcount = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入fetchcount'));
        } else {
          var reg = /[1-9][0-9]*$/;
          if (reg.test(value) && value.indexOf(".") < 0 && value < 10000) {
            callback();
          } else {
            callback(new Error('fetchout只能为数字,且大于0小于10000'));
          }
        }
      };
      var validatethreadnum = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入threadnum'));
        } else {
          var reg = /[1-9][0-9]*$/;
          if (reg.test(value) && value.indexOf(".") < 0 && value < 10000) {
            callback();
          } else {
            callback(new Error('threadnum只能为数字,且大于0小于10000'));
          }
        }
      };
      return {
        defaultexchange: 'DEFAULTEXCHANGE.0',
        disabledInput: false,
        prodLine: '',
        appNameOptions: '',
        consumerAppNameOptions: '',
        showMessage: true,
        routingkeyClass: '',
        queueClass: '',
        defaultClass: 'hide',
        infoArray: [],
        exchangeArray: [],
        queueArray: [],
        defaultQueueArray: [],
        form: {
          type: 'EXCHANGETYPE.0',
          prodLine: '',
          appName: '',
          consumerProdLine: '',
          consumerAppName: '',
          exchangename: '',
          queue: '',
          routingkey: '',
          creater: '',
          desc: '',
          checked: false,
          autoack: 'AUTOACK.0',
          fetchcount: '',
          threadnum: ''
        },
        rulesForm: {
          type: [
            {required: true, message: '请输入exchange名称', trigger: 'change'}
          ],
          exchangename: [
            {required: true, validator: validateExchangeName, trigger: 'blur'},
          ],
          queue: [
            {required: true, message: '请输入queue名称', trigger: 'blur'}
          ],
          prodLine: [
            {required: true, message: '请选择生产者产线', trigger: 'change'}
          ],
          appName: [
            {required: true, message: '请选择生产者应用', trigger: 'change'}
          ],
          consumerProdLine: [
            {required: true, message: '请选择消费者产线', trigger: 'change'}
          ],
          consumerAppName: [
            {required: true, message: '请选择消费者应用', trigger: 'change'}
          ],
          routingkey: [
            {required: true, message: '请输入bindingkey', trigger: 'blur'}
          ],
          creater: [
            {required: true, validator: validateCreater, trigger: 'blur'}
          ],
          desc: [
            {required: true, message: '请输入描述', trigger: 'blur'}
          ],
          fetchcount: [
            {required: true, validator: validatefetchcount, trigger: 'blur'}
          ],
          threadnum: [
            {required: true, validator: validatethreadnum, trigger: 'blur'}
          ]
        },
      }
    },
    mounted()
    {
      this.getAllProductLines();
      if (this.form.type == 'EXCHANGETYPE.0') {
        this.defaultClass = 'show'
      }
    }
    ,
    methods: {
      changeExchange()
      {
        if (this.form.checked == true) {
          this.form.exchangename = "";
          this.form.routingkey = "";
          this.defaultexchange = 'DEFAULTEXCHANGE.1';
          this.disabledInput = true;
          this.rulesForm.exchangename[0] = {trigger: 'blur'};
          this.showMessage = false;
          this.rulesForm.routingkey[0] = {trigger: 'blur'};
          this.queueArray = this.defaultQueueArray;
          this.routingkeyClass = 'hide';
          this.form.type = 'EXCHANGETYPE.0';
        } else {
          this.routingkeyClass = 'show';
          this.defaultexchange = 'DEFAULTEXCHANGE.0';
          this.disabledInput = false;
          this.rulesForm.exchangename[0] = {required: true, trigger: 'blur'};
          this.form.exchangename = "";
          this.showMessage = true;
          this.rulesForm.routingkey[0] = {required: true, message: '请输入bindingkey', trigger: 'blur'};
          this.form.queue = "";
        }
      }
      ,
      changeType(value)
      {
        if (value === 'EXCHANGETYPE.3') {
          this.defaultClass = 'show';
          this.disabledInput = false;
          this.rulesForm.exchangename[0].required = true;
          this.routingkeyClass = 'show';
          this.rulesForm.routingkey[0].required = true;

        } else if (value === 'EXCHANGETYPE.1') {
          this.defaultClass = 'show';
          this.disabledInput = false;
          this.rulesForm.exchangename[0].required = true;
          this.routingkeyClass = 'hide';
          this.form.routingkey = "";
          this.rulesForm.routingkey[0].required = false;
        } else {
          this.defaultClass = 'show';
          if (this.form.checked) {
            this.routingkeyClass = 'hide';
          } else {
            this.routingkeyClass = 'show';
          }
          this.rulesForm.routingkey[0].required = true;
        }
      }
      ,
      changeExchangeName()
      {
        this.form.queue = "";
        this.queueArray = [];
        for (var i = 0; i < this.infoArray.length; i++) {
          if (this.form.exchangename == this.infoArray[i].exchangename) {
            this.form.type = this.infoArray[i].type;
            this.changeType(this.form.type);
            this.queueArray.push(this.infoArray[i].queue);
          }
        }
      }
      ,
      getAllProductLines()
      {
        this.$store.dispatch('getAllProdLineList').then(val => {
          this.prodLine = val
        })
      }
      ,
      changePridLine(value)
      {
        this.form.appName = '';
        if (value == "") {
          return false
        }
        var id;
        for (var item in this.prodLine) {
          if (this.prodLine[item].abbrname == value) {
            id = this.prodLine[item].pid
          }
        }
        this.$store.dispatch('getAppNameList', id).then(val => {
          this.appNameOptions = val;
        })
      },
      changeConsumerPridLine(value)
      {
        this.form.consumerAppName = '';
        if (value == "") {
          return false
        }
        var id;
        for (var item in this.prodLine) {
          if (this.prodLine[item].abbrname == value) {
            id = this.prodLine[item].pid
          }
        }
        this.$store.dispatch('getAppNameList', id).then(val => {
          this.consumerAppNameOptions = val;
        })
      }
      ,
      getAppNameId(value)
      {
        this.form.exchangename = "";
        this.form.checked = false;
        this.disabledInput = false;
        if (value == "") {
          return false;
        }
        for (var item in this.appNameOptions) {
          if (this.appNameOptions[item].abbrname == value) {
            this.form.aid = this.appNameOptions[item].aid;
          }
        }
        var str = {"applicationid": this.form.aid};
        this.$store.dispatch('getByProductLineOrApplicationId', str).then(val => {
          this.infoArray = [];
          for (let i = 0; i < val.length; i++) {
            if (val[i].checkstatus == 'CHECKSTATUS.1') {
              this.infoArray.push(val[i]);
            }
          }
          this.exchangeArray = [];
          for (let i = 0; i < this.infoArray.length; i++) {
            if (this.exchangeArray.indexOf(this.infoArray[i].exchangename) == -1 && this.infoArray[i].exchangename != "") {
              this.exchangeArray.push(this.infoArray[i].exchangename);
            }
          }
          this.defaultQueueArray = [];
          for (let i = 0; i < this.infoArray.length; i++) {
            if (this.infoArray[i].exchangename == "") {
              this.defaultQueueArray.push(this.infoArray[i].queue);
            }
          }
        })
      },
      getConsumerAppNameId(value)
      {
        for (var item in this.consumerAppNameOptions) {
          if (this.consumerAppNameOptions[item].abbrname == value) {
            this.form.consumeraid = this.consumerAppNameOptions[item].aid;
          }
        }
      }
      ,
      submitForm(formName)
      {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            console.log(this.form.aid)
            var formData = {
              exchangename: this.form.exchangename,
              type: this.form.type,
              queue: this.form.queue,
              routingkey: this.form.routingkey,
              creater: this.form.creater,
              defaultexchange: this.defaultexchange,
              aid: this.form.aid,
              consumeraid: this.form.consumeraid,
              desc: this.form.desc,
              autoack: this.form.autoack,
              fetchcount: this.form.fetchcount,
              threadnum: this.form.threadnum
            }
            this.$store.dispatch('insertSubscribe', formData).then(val => {
              if (val.status == '200') {
                this.$message.success(val.message);
                this.$refs[formName].resetFields();
                //location.href  = '/consumer-list'
              } else {
                this.$message.error(val.message);
              }
            })
          } else {
            return false
          }
        })
      }
      ,
      resetForm(formName)
      {
        this.$refs[formName].resetFields();
      }
    }
  }
</script>
<style lang="scss" scoped>
  .title {
    margin: 0;
    color: #48576a;
    font-weight: 400;
    font-size: 16px;
  }

  .hide {
    display: none
  }

  .show {
    display: block
  }

  .checked {
    margin-top: 10px;
    padding-left: 10px;
  }
</style>
