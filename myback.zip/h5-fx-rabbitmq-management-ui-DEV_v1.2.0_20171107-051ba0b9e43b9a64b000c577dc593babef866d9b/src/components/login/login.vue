<template>
  <el-form autoComplete="on" :model="loginForm" ref="loginForm" label-position="left" label-width="0px"
           class="login-container">
    <h3 class="title">RabbitMQ消息治理</h3>
    <el-form-item prop="username">
      <el-input type="text" v-model="loginForm.username" autoComplete="on" placeholder="用户名" @keyup.enter.native="handleLogin"></el-input>
    </el-form-item>
    <el-form-item prop="password">
      <el-input name="password" type="password" v-model="loginForm.password" autoComplete="on"
                placeholder="密码" @keyup.enter.native="handleLogin"></el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" style="width:100%;" :loading="loading" @click.native.prevent="handleLogin">
        登录
      </el-button>
    </el-form-item>
  </el-form>
</template>

<script>
  export default {
    data() {
      return {
        loginForm: {
          username: '',
          password: ''
        },
        loading: false
      }
    },
    methods: {
      handleLogin() {
        if (this.loginForm.username == "" || this.loginForm.password == "") {
          this.$message.error('用户名和密码不能为空')
        } else {
          if (this.loginForm.username == "admin" && this.loginForm.password == "admin!1234") {
            sessionStorage.setItem('user', this.loginForm.username);
            this.$router.push('/');
          }else{
            if (this.loginForm.username == "user" && this.loginForm.password == "user!1234") {
              sessionStorage.setItem('user', this.loginForm.username);
              this.$router.push('/');
            }else{
              this.$message.error('用户名和密码不正确')
            }
          }
        }
      }
    }
  }
</script>

<style lang="scss">
  .login-container {
    -webkit-border-radius: 5px;
    border-radius: 5px;
    -moz-border-radius: 5px;
    background-clip: padding-box;
    width: 350px;
    padding: 35px 35px 15px 35px;
    background: #fff;
    border: 1px solid #eaeaea;
    box-shadow: 0 0 25px #cac6c6;
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    -moz-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    -o-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }

  .login-container .title {
    margin: 0px auto 40px auto;
    text-align: center;
    color: #505458;
  }

  /*.login-container {
    position: relative;
    height: 100vh;
    background-color: #2d3a4b;
    padding:0;
    margin:0;
    input:-webkit-autofill {
      -webkit-box-shadow: 0 0 0px 1000px #293444 inset !important;
      -webkit-text-fill-color: #fff !important;
    }
    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 12px 5px 12px 15px;
      color: #eeeeee;
      height: 47px;
    }
    .el-input {
      display: inline-block;
      height: 47px;
      width: 100%;
    }
    .title {
      font-size: 26px;
      font-weight: 400;
      color: #eeeeee;
      margin: 0px auto 40px auto;
      text-align: center;
      font-weight: bold;
    }
    .login-form {
      position: absolute;
      left: 0;
      right: 0;
      width: 400px;
      padding: 35px 35px 15px 35px;
      margin: 120px auto;
    }
    .el-form-item {
      border: 1px solid rgba(255, 255, 255, 0.1);
      background: rgba(0, 0, 0, 0.1);
      border-radius: 5px;
      color: #454545;
    }
    .forget-pwd {
      color: #fff;
    }
  }*/
</style>
