<template>
	<div class="management-wrap">
		<el-button type="primary" size="small" @click="addDialogWin">新增VHost用户信息</el-button>
		<el-dialog :title="title" :visible.sync="dialogWin" size="tiny" :show-close="false" :close-on-click-modal="false">
			<el-form :model="form" :rules="rulesForm" ref="form" label-width="90px">
				<el-input v-model="form.vid" type="hidden"></el-input>
				<el-form-item label="VHost："  prop="path">
			    	<el-input v-model="form.path" placeholder="请输入VHost名称" auto-complete="off"></el-input>
			    </el-form-item>
			    <el-form-item label="用户名："  prop="name">
			    	<el-input v-model="form.name" placeholder="请输入用户名" auto-complete="off"></el-input>
			    </el-form-item>
			    <el-form-item label="密码："  prop="password">
			    	<el-input v-model="form.password" placeholder="请输入密码" auto-complete="off"></el-input>
			    </el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
			    <el-button type="text"  @click="resetForm('form')">取 消</el-button>
			    <el-button type="primary"  @click="submitForm('form')">提 交</el-button>
			</div>
		</el-dialog>
		<div class="management-bd">
			<el-table :data="listPage" border>
				<el-table-column prop="path" label="VHost"></el-table-column>
				<el-table-column prop="name" label="用户名"></el-table-column>
				<el-table-column prop="password" label="密码"></el-table-column>
				<el-table-column label="操作">
			      <template scope="scope">
			        <el-button type="text" size="small" @click="update(scope.row)">修改</el-button>
			        <el-button type="text" size="small" @click="deleteRow(scope.row,scope.$index)">删除</el-button>
			      </template>
			    </el-table-column>
			</el-table>
		</div>
		<div class="management-ft">
			<el-pagination @current-change="currentChange" :current-page.sync="firstPage" layout="total,prev, pager, next" :page-size="pageSize" :total="totalSize" v-if="totalSize > 0">
			</el-pagination>
		</div>
	</div>
</template>
<script>
	export default{
		data(){
			var validateVHost = (rule, value, callback) => {
				if(value === ''){
					callback(new Error('请输入VHost名称'));
				}else{
					var reg = /^\//;
					if(reg.test(value)){
						callback();
					}else{
						callback(new Error('VHost名称必须以/开头'));
					}
				}
			};
			return{
				firstPage:1,
				totalSize:'',
				pageSize:10,
				dialogWin:false,
				title:'新增VHost用户信息',
				form:{
					path:'',
					name:'',
					password:'',
					vid:''
				},
				rulesForm:{
					path:[
						{ required:true, validator:validateVHost,trigger:'blur'}
					],
					name:[
						{ required:true, message:'请输入用户名',trigger:'blur'}
					],
					password:[
						{ required:true, message:'请输入密码',trigger:'blur'}
					]
				},
				list:[],
				listPage:[],
			}
		},
		mounted(){
			this.getAllVhostuser();
		},
		methods:{
			getAllVhostuser(){
				this.$store.dispatch('getAllVhostuser').then(val => {
					this.list = val;
					this.totalSize = val.length;
					if(this.totalSize <= this.pageSize){
	  					this.listPage = this.list.slice('0',this.list.length)
	  				}else{
	  					this.listPage = this.list.slice('0',this.pageSize)
	  				}
				})
			},
			currentChange(val){
		    	this.listPage = this.list.slice((val - 1)*this.pageSize,(val - 1)*this.pageSize+this.pageSize);
		    },
			addDialogWin(){
				this.dialogWin = true;
				this.title = '新增VHost用户信息';
				if(this.$refs.form){
					this.$refs.form.resetFields();
				}
				this.resetFromValue();
			},
			submitForm(formName){
				this.$refs[formName].validate((valid) => {
		          if (valid) {
		          	if(this.title === '修改VHost用户信息'){
		          		this.$store.dispatch('updateVhostuser',this.form).then(val =>{
		          			this.dialogWin = false;
		          			this.$refs[formName].resetFields();
		          			if(val.status == '200'){
		          				this.$message.success(val.data.resMessage);
		          				location.reload();
		          			}else{
		          				this.$message.error(val.data.resMessage);
		          			}
		          		})
		          	}else{
		          		this.$store.dispatch('insertVhostuser',this.form).then(val =>{
		          			this.dialogWin = false;
		          			this.$refs[formName].resetFields();
		          			if(val.status == '200'){
		          				this.$message.success(val.data.resMessage);
		          				location.reload();
		          			}else{
		          				this.$message.error(val.data.resMessage);
		          			}
		          		})
		          	}
		          }
		        })
			},
			update(row){
				this.title = '修改VHost用户信息';
				this.dialogWin = true;
				this.form = {
					path:row.path,
					name:row.name,
					password:row.password,
					vid:row.vid
				}
			},
			deleteRow(row,index){
				this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
		          confirmButtonText: '确定',
		          cancelButtonText: '取消',
		          type: 'warning'
		        }).then(() => {
			    	var id = row.vid;
			    	this.$store.dispatch('deleteVhostuser',id).then(val => {
			    		if(val.status == '200'){
							this.$message.success(val.data.resMessage);
	  						this.listPage.splice(index,1);
	  						this.totalSize = this.totalSize - 1;
						}else{
							this.$message.error(val.data.resMessage);
						}
			    	})
			    }).catch(() => {
		          this.$message({
		            type: 'info',
		            message: '已取消删除'
		          });
		        });
			},
			resetForm(formName){
		    	this.dialogWin = false;
		    	this.$refs[formName].resetFields();
		    	this.resetFromValue();
		    },
			resetFromValue(){
				this.form = {
					path:'',
					name:'',
					password:'',
					vid:''
				}
			}
		}
	}
</script>
<style scoped lang="scss">

</style>