<template>
  <div>
    <div class="management-wrap">
      <el-form label-width="200px">
        <el-form-item label="系统总开关">
          <el-switch
            v-model="value"
            on-color="#13ce66"
            off-color="#ff4949"
            on-text="开"
            off-text="关">
          </el-switch>
        </el-form-item>
        <el-form-item label="RabbitMQ Management 地址">
          <el-input v-model="rmUrl"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="changestatus()">保存</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
  export default{
    data(){
      return {
        title: '系统配置',
        masterSwitch: {},
        msg: '',
        value:false,
        rmUrl: 'http://192.168.33.117:15672/api'
      }
    },
    mounted(){
      this.getMasterSwitchStatus();
    },
    methods: {
      getMasterSwitchStatus(){
        this.$store.dispatch('getMasterSwitchStatus').then(val => {
          this.msg = val;
          this.value = val.masterSwitch;
          this.rmUrl = val.rmUrl;
        })
      },
      changestatus(){
        let data = {masterSwitch: this.value, rmUrl: this.rmUrl};
        this.$store.dispatch('setMasterSwitchStatus', data).then(val => {
          if (val) {
            this.$message.success("修改成功");
          } else {
            this.$message.error("修改失败");
          }
        })
      }
    }
  }
</script>
<style scoped lang="scss">

</style>
