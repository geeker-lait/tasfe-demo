<template>
	<div class="management-wrap">
		<el-button type="primary" size="small" @click="addDialogWin">新增产线</el-button>
		<el-dialog :title="title" :visible.sync="dialogWin" size="tiny" :show-close="false" :close-on-click-modal="false">
			<el-form :model="form" :rules="rulesForm" ref="form" label-width="120px">
				<el-input v-model="form.pid" type="hidden" auto-complete="off"></el-input>
				<el-form-item label="产线名称："  prop="name">
			    	<el-input v-model="form.name" placeholder="请输入产线名称" auto-complete="off"></el-input>
			    </el-form-item>
			    <el-form-item label="产线简称："  prop="abbrname">
			    	<el-input v-model="form.abbrname" placeholder="请输入产线简称" auto-complete="off"></el-input>
			    </el-form-item>
			    <el-form-item label="描述："  prop="desc">
			    	<el-input v-model="form.desc" placeholder="请输入描述" type="textarea" auto-complete="off"></el-input>
			    </el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
			    <el-button type="text"  @click="resetForm('form')">取 消</el-button>
			    <el-button type="primary"  @click="submitForm('form')">提 交</el-button>
			</div>
		</el-dialog>
		<div class="management-bd">
			<el-table :data="listPage" border>
				<el-table-column prop="name" label="产线名称"></el-table-column>
				<el-table-column prop="abbrname" label="产线简称"></el-table-column>
				<el-table-column prop="desc" label="描述"></el-table-column>
				<el-table-column label="操作">
					<template scope="scope">
				        <el-button type="text" size="small" @click="update(scope.row)">修改</el-button>
				        <el-button type="text" size="small" @click="deleteRow(scope.row,scope.$index)">删除</el-button>
				     </template>
				</el-table-column>
			</el-table>
		</div>
		<div class="management-ft">
			<el-pagination @current-change="currentChange" :current-page.sync="firstPage" layout="total,prev, pager, next" :page-size="pageSize" :total="totalSize" v-if="totalSize > 0">
			</el-pagination>
		</div>
	</div>
</template>
<script>
	export default{
		data(){
			var validateName = (rule, value, callback) => {
				if(value === ''){
					callback(new Error('请输入产线名称'));
				}else{
					var reg = /^[\u4e00-\u9fa5]/;
					if(reg.test(value)){
						callback();
					}else{
						callback(new Error('产线名称只能是汉字'));
					}
				}
			};
			var validateAbbrName = (rule, value, callback) => {
				if(value === ''){
					callback(new Error('请输入产线简称'));
				}else{
					var reg = /^[A-Za-z]+$/;
					if(reg.test(value)){
						callback();
					}else{
						callback(new Error('产线简称只能是字母'));
					}
				}
			};
			return{
				firstPage:1,
				totalSize:'',
				pageSize:10,
				dialogWin:false,
				title:'新增产线',
				form:{
					name:'',
					abbrname:'',
					desc:'',
					pid:''
				},
				rulesForm:{
					name:[
						{ required:true, validator:validateName,trigger:'blur'}
					],
					abbrname:[
						{ required:true, validator:validateAbbrName,trigger:'blur'}
					],
					desc:[
						{ required:true, message:'请输入描述',trigger:'blur'}
					]
				},
				list:[],
				listPage:[]
			}
		},
		mounted(){
			this.getAllProdLine()
		},
		methods:{
			getAllProdLine(){
				this.$store.dispatch('getAllProdLine').then(val=> {
					this.list = val;
					this.totalSize = val.length;
					if(this.totalSize <= this.pageSize){
	  					this.listPage = this.list.slice('0',this.list.length)
	  				}else{
	  					this.listPage = this.list.slice('0',this.pageSize)
	  				}
				})
			},
			currentChange(val){
		    	this.listPage = this.list.slice((val - 1)*this.pageSize,(val - 1)*this.pageSize+this.pageSize);
		    },
			addDialogWin(){
				this.dialogWin = true;
				this.title = '新增产线';
				if(this.$refs.form){
					this.$refs.form.resetFields();
				}
				this.resetFromValue();
			},
			submitForm(formName){
				this.$refs[formName].validate((valid) => {
		          if (valid) {
		          	if(this.title === '修改产线信息'){
		          		this.$store.dispatch('updateProductLine',this.form).then(val =>{
		          			this.dialogWin = false;
		          			this.$refs[formName].resetFields();
		          			if(val.status == '200'){
		          				this.$message.success(val.data.resMessage);
		          				location.reload();
		          			}else{
		          				this.$message.error(val.data.resMessage)
		          			}
		          		})
		          	}else{
		          		this.$store.dispatch('insertProduceLine',this.form).then(val =>{
		          			this.dialogWin = false;
		          			this.$refs[formName].resetFields();
		          			if(val.status == '200'){
		          				this.$message.success(val.data.resMessage);
		          				location.reload();
		          			}else{
		          				this.$message.error(val.data.resMessage)
		          			}
		          		})
		          	}
		          }
		        })
			},
			update(row){
				this.title = '修改产线信息';
				this.dialogWin = true;
				this.form = {
					name:row.name,
					abbrname:row.abbrname,
					desc:row.desc,
					pid:row.pid
				}

			},
			deleteRow(row,index){
				this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
		          confirmButtonText: '确定',
		          cancelButtonText: '取消',
		          type: 'warning'
		        }).then(() => {
			    	var pid = row.pid;
			    	this.$store.dispatch('deleteProductLine',pid).then(val => {
			    		if(val.status == '200'){
							this.$message.success(val.data.resMessage);
	  						this.listPage.splice(index,1);
	  						this.totalSize = this.totalSize - 1;
						}else{
							this.$message.error(val.data.resMessage);
						}
			    	})
			    }).catch(() => {
		          this.$message({
		            type: 'info',
		            message: '已取消删除'
		          });
		        });
			},
			resetForm(formName){
		    	this.dialogWin = false;
		    	this.$refs[formName].resetFields();
		    	this.resetFromValue();
		    },
			resetFromValue(){
				this.form = {
					name:'',
					abbrname:'',
					desc:'',
					pid:''
				}
			}
		}	
	}
</script>