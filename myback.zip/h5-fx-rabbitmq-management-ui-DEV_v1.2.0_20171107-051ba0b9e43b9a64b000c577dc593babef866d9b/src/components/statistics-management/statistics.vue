<template>
  <div style="height: 100%;">
    <div style="height: 5%">
      <el-button>刷新</el-button>
    </div>
    <div id="myChart" :style="{width: '100%', height: '95%'}"></div>
  </div>
</template>
<script>
  export default{
    data(){
      return {
        msg: 'hello world '
      }
    },
    mounted(){
      let that = this;
      let myChart = this.$echarts.init(document.getElementById('myChart'));
      myChart.on('click', function (params) {
        if (params.dataType == 'edge' && params.value == 'channelnodeedge') {
          console.log(params);
          switch (params.data.connectionstatus) {
            case "connected":
              that.handleClickConnected(params);
              break;
            case "disconnected":
              that.handleClickDisconnected(params);
              break;
            default:
              break;
          }
        }
      });
      that.myChart = myChart;
      that.drawLine();
    },
    methods: {
      handleClickConnected: function (params) {
        alert('确定要断开节点' + params.data.target);
      },
      handleClickDisconnected: function (params) {
        alert('确定要重连节点' + params.data.target);
      },
      drawLine: function () {
        let productLineColor = '#0099CC';
        let appNameColor = '#0099CC';
        let productLineColorConsumer = '#99CC33';
        let appNameColorConsumer = '#99CC33';
        let exchangeColor = '#FF9933';
        let queueColor = '#99CC99';
        let channelColor = '#FF99CC';
        let seriesColorState1 = '#99CC33';
        let seriesColorState2 = '#CC0033';
        let seriesColorState3 = '#CC0033';
        let defaultSymbolSize = 15;
        let productLineSymbolSize = 15;
        let appNameSymbolSize = 15;
        let exchangeSymbolSize = 15;
        let queueSymbolSize = 15;
        let channelSymbolSize = 15;
        let option = {
          title: {
            text: ''
          },
          tooltip: {
            trigger: 'item',
            formatter: function (params) {
              switch (params.data.type) {
                case 'productline':
                  return "产线：XXXX <br/> 简称:XXXXX";
                  break;
                case 'app':
                  return "应用:XXXX<br/>描述:XXXXXX";
                  break;
                case 'exchange':
                  return "exchange名称:XXXX<br/>exchange类型:XXXXX<br/>routing-key:XXXX<br/>是否持久化:XX<br/>是否自动删除:XXXX<br/>是否internal:XXX<br/>创建者:XXXX";
                  break;
                case 'queue':
                  return "queue名称:XXX<br/>autoack:XXX<br/>fetchcount:XXXX<br/>threadnum:XXX<br/>创建者:XXXX<br/>描述:XXXXX";
                  break;
                case 'channel':
                  return "channel ip:XXXX<br/>channel port:XXXX<br/>状态:XXX<br/>channel number:XXX<br/>exchange类型：XXXX<br/>binndingkey:XXXX<br/>描述:XXXXX";
                  break;
                default:
                  return "";
              }
            }
          },
          animationDurationUpdate: 1500,
          animationEasingUpdate: 'quinticInOut',
          series: [
            {
              type: 'graph',
              layout: 'none',
              symbolSize: defaultSymbolSize,
              roam: true,
              focusNodeAdjacency: true,
              label: {
                normal: {
                  show: true,
                  textBorderColor: 'transparent',
                  color: '#555',
                  fontWeight: 'bold',
                  position: 'bottom'
                }
              },
              edgeSymbol: ['circle', 'arrow'],
              edgeSymbolSize: [4, 10],
              edgeLabel: {
                normal: {
                  textStyle: {
                    fontSize: 20
                  }
                }
              },
              data: [{
                name: '生产者-手机贷',
                x: 100,
                y: 100,
                type: 'productline',
                symbolSize: productLineSymbolSize,
                itemStyle: {normal: {color: productLineColor}}
              }, {
                name: '生产者-财务',
                x: 100,
                y: 300,
                type: 'productline',
                symbolSize: productLineSymbolSize,
                itemStyle: {normal: {color: productLineColor}}
              }, {
                name: '生产者-风控',
                x: 100,
                y: 500,
                type: 'productline',
                symbolSize: productLineSymbolSize,
                itemStyle: {normal: {color: productLineColor}}

              }, {
                name: '消费者-风控',
                x: 1300,
                y: 200,
                type: 'productline',
                symbolSize: productLineSymbolSize,
                itemStyle: {normal: {color: productLineColorConsumer}}
              }, {
                name: '消费者-框架',
                x: 1300,
                y: 400,
                type: 'productline',
                symbolSize: productLineSymbolSize,
                itemStyle: {normal: {color: productLineColorConsumer}}
              }, {
                name: 'activity',
                x: 300,
                y: 0,
                type: 'app',
                symbolSize: appNameSymbolSize,
                itemStyle: {normal: {color: appNameColor}}
              }, {
                name: 'micro_site',
                x: 300,
                y: 150,
                type: 'app',
                symbolSize: appNameSymbolSize,
                itemStyle: {normal: {color: appNameColor}}
              }, {
                name: 'captical',
                x: 300,
                y: 300,
                type: 'app',
                symbolSize: appNameSymbolSize,
                itemStyle: {normal: {color: appNameColor}}
              }, {
                name: 'pay',
                x: 300,
                y: 450,
                type: 'app',
                symbolSize: appNameSymbolSize,
                itemStyle: {normal: {color: appNameColor}}
              }, {
                name: 'bussiness_ci',
                x: 300,
                y: 600,
                type: 'app',
                symbolSize: appNameSymbolSize,
                itemStyle: {normal: {color: appNameColor}}
              }, {
                name: 'bussiness_xs',
                x: 300,
                y: 750,
                type: 'app',
                symbolSize: appNameSymbolSize,
                itemStyle: {normal: {color: appNameColor}}
              }, {
                name: 'rca_commit',
                x: 1100,
                y: 200,
                type: 'app',
                symbolSize: appNameSymbolSize,
                itemStyle: {normal: {color: appNameColorConsumer}}
              }, {
                name: 'rabbitmq-exmaple',
                x: 1100,
                y: 400,
                type: 'app',
                symbolSize: appNameSymbolSize,
                itemStyle: {normal: {color: appNameColorConsumer}}
              }, {
                name: 'Exchange1',
                x: 500,
                y: 200,
                type: 'exchange',
                symbol: 'rect',
                symbolSize: exchangeSymbolSize,
                itemStyle: {normal: {color: exchangeColor}}
              }, {
                name: 'Exchange2',
                x: 500,
                y: 400,
                type: 'exchange',
                symbol: 'rect',
                symbolSize: exchangeSymbolSize,
                itemStyle: {normal: {color: exchangeColor}}
              }, {
                name: 'queue1',
                x: 700,
                y: 100,
                type: 'queue',
                symbol: 'rect',
                symbolSize: queueSymbolSize,
                itemStyle: {normal: {color: queueColor}}
              }, {
                name: 'queue2',
                x: 700,
                y: 300,
                type: 'queue',
                symbol: 'rect',
                symbolSize: queueSymbolSize,
                itemStyle: {normal: {color: queueColor}}
              }, {
                name: 'queue3',
                x: 700,
                y: 500,
                type: 'queue',
                symbol: 'rect',
                symbolSize: queueSymbolSize,
                itemStyle: {normal: {color: queueColor}}
              }, {
                name: 'node1',
                x: 900,
                y: 100,
                type: 'channel',
                symbol: 'rect',
                symbolSize: channelSymbolSize,
                itemStyle: {normal: {color: channelColor}}
              }, {
                name: 'node2',
                x: 900,
                y: 200,
                type: 'channel',
                symbol: 'rect',
                symbolSize: channelSymbolSize,
                itemStyle: {normal: {color: channelColor}}
              }, {
                name: 'node3',
                x: 900,
                y: 300,
                type: 'channel',
                symbol: 'rect',
                symbolSize: channelSymbolSize,
                itemStyle: {normal: {color: channelColor}}
              }],
              // links: [],
              links: [
                {
                  source: '生产者-手机贷',
                  target: 'activity',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: '生产者-手机贷',
                  target: 'micro_site',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: '生产者-财务',
                  target: 'captical',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: '生产者-财务',
                  target: 'pay',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: '生产者-风控',
                  target: 'bussiness_ci',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: '生产者-风控',
                  target: 'bussiness_xs',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: '消费者-风控',
                  target: 'rca_commit',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: '消费者-框架',
                  target: 'rabbitmq-exmaple',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: 'micro_site',
                  target: 'Exchange1',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: 'Exchange1',
                  target: 'queue2',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: 'queue2',
                  target: 'node1',
                  value: 'channelnodeedge',
                  connectionstatus: 'connected',
                  label: {
                    normal: {
                      show: true,
                      formatter: '消费中...',
                      fontSize: 10
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: 'queue2',
                  target: 'node2',
                  value: 'channelnodeedge',
                  connectionstatus: 'connected',
                  label: {
                    normal: {
                      show: true,
                      formatter: '消费中...',
                      fontSize: 10
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: 'queue2',
                  target: 'node3',
                  value: 'channelnodeedge',
                  connectionstatus: 'disconnected',
                  label: {
                    normal: {
                      show: true,
                      formatter: '断开',
                      fontSize: 10
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState2,
                    }
                  }
                }, {
                  source: 'node1',
                  target: 'rca_commit',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: 'node2',
                  target: 'rca_commit',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }, {
                  source: 'node3',
                  target: 'rca_commit',
                  label: {
                    normal: {
                      show: true,
                      formatter: ''
                    }
                  },
                  lineStyle: {
                    normal: {
                      color: seriesColorState1,
                    }
                  }
                }],
              lineStyle: {
                normal: {
                  opacity: 0.9,
                  width: 2,
                  curveness: 0
                }
              }
            }
          ]
        };
        this.myChart.setOption(option);
      }
    },
  }
</script>
<style>
  .content-container {
    height: 100%;
    padding: 0;
    margin: 0;
  }

  .content-wrapper {
    height: 90%;
  }

  .grid-content {
    height: 100%;
  }
</style>
