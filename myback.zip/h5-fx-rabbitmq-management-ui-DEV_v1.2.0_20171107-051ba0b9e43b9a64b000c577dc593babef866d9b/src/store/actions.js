import apiConfig from './api/http';
export const getAllProdLineList = ({commit, state, dispatch}) => {
  var load = new apiConfig.urlApi.produceline.getAll();
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success.data;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const getAppNameList = ({commit, state, dispatch},str) => {
	var param = "";
	param += 'id='+str;
	var load = new apiConfig.urlApi.application.getByProductLineId();
	load.url = load.url + '?'+param;
	return new Promise((resolve, reject) => {
		return load.exec(function( success ){
		  var obj = success.data;
		  resolve(obj);
		},function( error ){
		  
		  console.log( error );
		})
	});
};