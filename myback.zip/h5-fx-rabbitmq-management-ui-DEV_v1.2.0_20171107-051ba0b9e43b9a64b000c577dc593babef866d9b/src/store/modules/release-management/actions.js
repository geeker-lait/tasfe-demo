import apiConfig from '../../api/http';

export const insertPublish = ({commit, state, dispatch},str) => {
  	var load = new apiConfig.urlApi.publish.insertPublish();
    load.param = str;
  	//load.url = load.url + '?'+param;
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const updatePublish = ({commit, state, dispatch},str) => {
  	var load = new apiConfig.urlApi.publish.updatePublish();
    load.param = str;
  	//load.url = load.url + '?'+param;
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const checkPublish = ({commit, state, dispatch},str) => {
	var param = "";
  	param += 'publishid='+str.publishid+'&checkstatus='+str.checkstatus;
  	var load = new apiConfig.urlApi.publish.checkPublish();
  	load.url = load.url + '?'+param;
  	load.type = "get";
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const deletePublish = ({commit, state, dispatch},str) => {
	var param = "";
	param += 'id='+str;
	var load = new apiConfig.urlApi.publish.deletePublish();
	load.url = load.url + '?'+param;
	return new Promise((resolve, reject) => {
		return load.exec(function( success ){
		  var obj = success;
		  resolve(obj);
		},function( error ){

		  console.log( error );
		})
	});
};
export const getAllExchange = ({commit, state, dispatch}) => {
  var load = new apiConfig.urlApi.publish.getAllExchange();
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj;
      if(success.data){
        obj = success.data;
      }else{
        obj = []
      }
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const getByProductLineOrApplicationId = ({commit, state, dispatch},str) => {
    var param = "";
    param += 'productLineId='+str.productLineId+'&applicationid='+str.applicationid;
    var load = new apiConfig.urlApi.publish.getByProductLineOrApplicationId();
    load.url = load.url + '?'+param;
    load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj;
      if(success.data){
        obj = success.data;
      }else{
        obj = []
      }
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
