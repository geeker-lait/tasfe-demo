import apiConfig from '../../../api/http';

export const getAllVhostuser = ({commit, state, dispatch}) => {
  var load = new apiConfig.urlApi.vhostuser.getAll();
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success.data;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const insertVhostuser = ({commit, state, dispatch},str) => {
	var param = "";
  	param += 'path='+str.path+'&name='+str.name+'&password='+str.password;
  	var load = new apiConfig.urlApi.vhostuser.insertVhostuser();
  	load.url = load.url + '?'+param;
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const updateVhostuser = ({commit, state, dispatch},str) => {
	var param = "";
  	param += 'vid='+str.vid+'&path='+str.path+'&name='+str.name+'&password='+str.password;
  	var load = new apiConfig.urlApi.vhostuser.updateVhostuser();
  	load.url = load.url + '?'+param;
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const deleteVhostuser = ({commit, state, dispatch},str) => {
	var param = "";
	param += 'id='+str;
	var load = new apiConfig.urlApi.vhostuser.deleteVhostuser();
	load.url = load.url + '?'+param;
	return new Promise((resolve, reject) => {
		return load.exec(function( success ){
		  var obj = success;
		  resolve(obj);
		},function( error ){
		  
		  console.log( error );
		})
	});
};