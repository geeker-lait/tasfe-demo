import * as types from './mutation-types'
import Vue from 'vue'

export default {
	//console.log(1)
	// [types.CONFIG] (state,aa) {
	// 	console.log(state)
	//     Vue.set(state, 'aa', aa);
	//  }
}
