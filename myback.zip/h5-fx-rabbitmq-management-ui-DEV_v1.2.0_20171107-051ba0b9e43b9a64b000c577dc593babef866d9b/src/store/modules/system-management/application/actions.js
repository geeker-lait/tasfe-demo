import apiConfig from '../../../api/http';

export const getAllProdLineOptions = ({commit, state, dispatch}) => {
  var load = new apiConfig.urlApi.produceline.getAll();
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success.data;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const getAllApplication = ({commit, state, dispatch}) => {
  var load = new apiConfig.urlApi.application.getAll();
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success.data;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const insertAppliation = ({commit, state, dispatch},str) => {
	var param = "";
  	param += 'name='+str.name+'&abbrname='+str.abbrname+'&desc='+str.desc+'&pid='+str.pid;
  	var load = new apiConfig.urlApi.application.insertAppliation();
  	load.url = load.url + '?'+param;
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const updateApplication = ({commit, state, dispatch},str) => {
	var param = "";
  	param += 'aid='+str.aid+'&name='+str.name+'&abbrname='+str.abbrname+'&desc='+str.desc+'&pid='+str.pid;
  	var load = new apiConfig.urlApi.application.updateApplication();
  	load.url = load.url + '?'+param;
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const deleteApplication = ({commit, state, dispatch},str) => {
	var param = "";
	param += 'id='+str;
	var load = new apiConfig.urlApi.application.deleteApplication();
	load.url = load.url + '?'+param;
	return new Promise((resolve, reject) => {
		return load.exec(function( success ){
		  var obj = success;
		  resolve(obj);
		},function( error ){
		  
		  console.log( error );
		})
	});
};