import apiConfig from '../../../api/http';

export const getMasterSwitchStatus = ({commit, state, dispatch}) => {
  var load = new apiConfig.urlApi.systemconfig.getMasterSwitchStatus();
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const setMasterSwitchStatus = ({commit, state, dispatch}, data) => {
  var load = new apiConfig.urlApi.systemconfig.setMasterSwitchStatus();
  load.param = data;
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
