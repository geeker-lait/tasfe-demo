//定义变量
//export const CONFIG = 'CONFIG'