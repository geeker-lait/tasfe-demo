import apiConfig from '../../api/http';

export const insertSubscribe = ({commit, state, dispatch},str) => {
  	var load = new apiConfig.urlApi.subscribe.insertSubscribe();
    load.param = str;
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const updateSubscribe = ({commit, state, dispatch},str) => {
  	var load = new apiConfig.urlApi.subscribe.updateSubscribe();
    load.param = str;
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const checkSubscribe = ({commit, state, dispatch},str) => {
	var param = "";
  	param += 'subscribeid='+str.subscribeid+'&checkstatus='+str.checkstatus;
  	var load = new apiConfig.urlApi.subscribe.checkSubscribe();
  	load.url = load.url + '?'+param;
  	load.type = "get";
  	return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const deleteSubscribe = ({commit, state, dispatch},str) => {
	var param = "";
	param += 'subscribeid='+str;
	var load = new apiConfig.urlApi.subscribe.deleteSubscribe();
	load.url = load.url + '?'+param;
  load.type = "get";
	return new Promise((resolve, reject) => {
		return load.exec(function( success ){
		  var obj = success;
		  resolve(obj);
		},function( error ){
		  
		  console.log( error );
		})
	});
};
export const getAllSubscribe = ({commit, state, dispatch}) => {
  var load = new apiConfig.urlApi.subscribe.getAllSubscribe();
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success.data;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const getByProductLine = ({commit, state, dispatch},str) => {
    var param = "";
    param += 'pid='+str.pid+'&aid='+str.aid;
    var load = new apiConfig.urlApi.subscribe.getByProductLine();
    load.url = load.url + '?'+param;
    load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success.data;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const getCollections = ({commit, state, dispatch},str) => {
  var param = "";
  param += 'productline='+str.productline+'&application='+str.application;
  var load = new apiConfig.urlApi.rabbitmqManagement.getCollections();
  load.url = load.url + '?'+param;
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success.data;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const getChannels = ({commit, state, dispatch},str) => {
  var param = "";
  param += 'name='+str;
  var load = new apiConfig.urlApi.rabbitmqManagement.getChannels();
  load.url = load.url + '?'+param;
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success.data;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};
export const runStatus = ({commit, state, dispatch},str) => {
  var param = "";
  param += 'runstatus='+str.runstatus+'&channelid='+str.channelid+'&productline='+str.productline+'&application='+str.application+'&ip='+str.ip+'&port='+str.port;
  var load = new apiConfig.urlApi.rabbitmqManagement.runStatus();
  load.url = load.url + '?'+param;
  load.type = "get";
  return new Promise((resolve, reject) => {
    return load.exec(function (success) {
      var obj = success;
      resolve(obj);
    }, function (error) {
      console.log(error);
    })
  });
};