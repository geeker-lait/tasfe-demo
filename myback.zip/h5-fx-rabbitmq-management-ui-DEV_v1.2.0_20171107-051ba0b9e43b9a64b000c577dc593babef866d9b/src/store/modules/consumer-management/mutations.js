import * as types from './mutation-types'
import Vue from 'vue'

export default {
}
