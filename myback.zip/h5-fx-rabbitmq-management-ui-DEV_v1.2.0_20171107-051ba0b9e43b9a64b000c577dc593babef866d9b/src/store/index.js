import Vue from 'vue';
import Vuex from 'vuex';
//import * as mutations from './mutations';
import * as actions from './actions';
import releasemanagement from './modules/release-management';
import consumermanagement from './modules/consumer-management';
import vhostUser from './modules/system-management/vhostuser';
import prodLine from './modules/system-management/prodline';
import application from './modules/system-management/application';
import systemconfig from './modules/system-management/systemconfig'

Vue.use(Vuex);

const store = new Vuex.Store({
  state: {},
  //mutations: mutations.default,
  actions,
  modules: {
    releasemanagement,
    consumermanagement,
    vhostUser,
    prodLine,
    application,
    systemconfig
  },
  strict: process.env.NODE_ENV !== 'production'
});
export default store;
