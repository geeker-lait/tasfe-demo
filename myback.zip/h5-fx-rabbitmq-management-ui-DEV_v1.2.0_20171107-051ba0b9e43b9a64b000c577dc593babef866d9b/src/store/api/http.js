import axios from 'axios'
function extend(p, c) {
  var c = c || {};
  for (var i in p) {
    if(typeof p[i] === 'object') {
      c[i] = (p[i].constructor === Array) ? [] : {};
      extend(p[i], c[i]);
    } else {
      c[i] = p[i];
    }
  }
  return c;
}
/*
 * @type : get/post ， 默认post,
 * @success : 请求成功callback
 * @error : 请求失败callback

 ajax请求使用 eq:
 var load = new api.urlApi.resource.getResourceDetail();
 load.param = {
 userName: 'normal',
 password:'b123456'
 }
 load.exec(function( success ){
 console.info("success:"+success.msg);
 },function( error ){
 console.info("error");
 })
 */
function Ajax() {}
Ajax.prototype.exec = function (success, error) {
  var wait = this.wait || false; //是否是多个请求
  var type = (this.type || 'post').toLowerCase(); //get/post ， 默认post,
  var dataType = this.dataType || 'application/x-www-form-urlencoded';
  var url = this.url || '';
  var params = this.param || {};
  //params.token = sessionStorage.getItem('token');
  if( type === 'post' && this.dataType){
    axios.defaults.headers.post['Content-Type'] = 'application/json';
  }
  axios[ type ]( url , params )
    .then(function ( ret ) {
      if( ret.statusText === 'OK'){
        if( ret.data.status === 'success' || ret.data.status === '1' ||  ret.status === 200){
          success && success( ret.data );
        }else{
          if( ret.data.msg == '未登录'){
            window.location.href = '/#';
          }else{
            error && error( ret.data.msg || ret.data.error);
          }

        }
      }
    }).catch(function ( ret ) {
    error && error( ret.message );
  });
};
var Inherit = {};
Inherit.Class = function( obj ){
  obj.prototype = extend( obj.prototype , Ajax.prototype );
  return obj;
}

// function AjaxAll( ...params ){
// 	var aaa = params;
// 	axios.all([aaa])
// 	//axios.all([getUserAccount(), getUserPermissions()])
// 	  .then(axios.spread(function (account, permission) {
// 	  	callback && callback( account );
// 	    //all 会等到所有请求都完成,
// 	  }));
// }

// var baseUrl = "";
// if(process.env === 'dev'){
// 	baseUrl = url_dev;
// }else if(process.env === 'sat'){
// 	baseUrl = url_sat;
// }else if(process.env === 'prod'){
// 	baseUrl = url_prod;
// }

//var baseUrl = "http://127.0.0.1:8180";
var baseUrl = window.res__;
// var baseUrl = "http://192.168.25.148:8888";
//所有请求路径参数配置入口
const urlApi = {
    //baseUrl : "http://192.168.1.165:8180",  //线上
    //baseUrl : "http://192.168.1.241:8180",  //李浪
    //baseUrl:"http://192.168.25.67:8888",
    baseUrl : baseUrl,
    vhostuser : {//VHost用户名密码
      getAll : Inherit.Class(function(){ //新增
        this.url = urlApi.baseUrl+"/vhostuser/getAll";
      }),
      insertVhostuser:Inherit.Class(function(){
        this.url = urlApi.baseUrl + "/vhostuser/insertVhostuser";
      }),
      updateVhostuser:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/vhostuser/updateVhostuser'
      }),
      deleteVhostuser:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/vhostuser/deleteById'
      })
    },
    produceline:{
      getAll : Inherit.Class(function(){ //新增
        this.url = urlApi.baseUrl+"/produceline/getAll";
      }),
      insertProduceLine:Inherit.Class(function(){
        this.url = urlApi.baseUrl + "/produceline/insertProduceLine";
      }),
      updateProductLine:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/produceline/updateProductLine'
      }),
      deleteProductLine:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/produceline/deleteById'
      })
    },
    application:{
      getAll : Inherit.Class(function(){ //新增
        this.url = urlApi.baseUrl+"/application/getAll";
      }),
      insertAppliation:Inherit.Class(function(){
        this.url = urlApi.baseUrl + "/application/insertAppliation";
      }),
      updateApplication:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/application/updateApplication'
      }),
      deleteApplication:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/application/deleteById'
      }),
      getByProductLineId:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/application/getByProductLineId'
      })
    },
    publish:{
      insertPublish:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/publish/insertPublish'
      }),
      updatePublish:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/publish/updatePublish'
      }),
      checkPublish:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/publish/checkPublish'
      }),
      deletePublish:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/publish/deleteById'
      }),
      getAllExchange:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/publish/getAll'
      }),
      getByProductLineOrApplicationId:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/publish/getByProductLineOrApplicationId'
      })
    },
    subscribe:{
      insertSubscribe:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/subscribe/insertSubscribe'
      }),
      getAllSubscribe:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/subscribe/getAll'
      }),
      updateSubscribe:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/subscribe/update'
      }),
      deleteSubscribe:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/subscribe/deleteById'
      }),
      checkSubscribe:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/subscribe/checkSubscribe'
      }),
      getByProductLine:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/subscribe/getByProductLine'
      })
    },
    rabbitmqManagement:{
      getCollections:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/rabbitmqManagement/getCollections'
      }),
      getChannels:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/rabbitmqManagement/getChannels'
      }),
      runStatus:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/rabbitmqManagement/run'
      })
    },
    systemconfig:{
      getMasterSwitchStatus:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/systemconfig/getMasterSwitchStatus'
      }),
      setMasterSwitchStatus:Inherit.Class(function(){
        this.url = urlApi.baseUrl + '/systemconfig/setMasterSwitchStatus'
      })
    }
  };

export default {urlApi}
