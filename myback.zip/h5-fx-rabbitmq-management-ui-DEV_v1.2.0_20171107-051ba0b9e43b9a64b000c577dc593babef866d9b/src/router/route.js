const Home = resolve => {
  require.ensure(['@/components/home'], () => {
    resolve(require('@/components/home'))
  });
};
const List = resolve => {
  require.ensure(['@/components/release-management/list'], () => {
    resolve(require('@/components/release-management/list'))
  });
};
const Review = resolve => {
  require.ensure(['@/components/release-management/review'], () => {
    resolve(require('@/components/release-management/review'))
  });
};
const Application = resolve => {
  require.ensure(['@/components/release-management/application'], () => {
    resolve(require('@/components/release-management/application'))
  });
};
const ConsumerApplication = resolve => {
  require.ensure(['@/components/consumer-management/application'], () => {
    resolve(require('@/components/consumer-management/application'))
  });
};
const ConsumerList = resolve => {
  require.ensure(['@/components/consumer-management/list'], () => {
    resolve(require('@/components/consumer-management/list'))
  });
};
const ConsumerReview = resolve => {
  require.ensure(['@/components/consumer-management/review'], () => {
    resolve(require('@/components/consumer-management/review'))
  });
};
const ConsumerQuery = resolve => {
  require.ensure(['@/components/consumer-management/query'], () => {
    resolve(require('@/components/consumer-management/query'))
  });
};
const AppName = resolve => {
  require.ensure(['@/components/system-management/appname'], () => {
    resolve(require('@/components/system-management/appname'))
  });
};
const ProdLine = resolve => {
  require.ensure(['@/components/system-management/prodline'], () => {
    resolve(require('@/components/system-management/prodline'))
  });
};
const UserPassword = resolve => {
  require.ensure(['@/components/system-management/user-password'], () => {
    resolve(require('@/components/system-management/user-password'))
  });
};
const Login = resolve => {
  require.ensure(['@/components/login/login'], () => {
    resolve(require('@/components/login/login'))
  })
};
const SystemConfig = resolve => {
  require.ensure(['@/components/system-management/systemconfig'], () => {
    resolve(require('@/components/system-management/systemconfig'))
  })
};
const Statistics = resolve => {
  require.ensure(['@/components/statistics-management/statistics'], () => {
    resolve(require('@/components/statistics-management/statistics'))
  })
};
const routers = [
  {
    path: '/',
    redirect: '/release-application',
  },
  {
    path: '/login',
    component: Login,
    name: '',
    hidden: true
  },
  {
    path: '',
    component: Home,
    name: '发布管理',
    iconCls: 'el-icon-menu',
    children: [
      {
        path: '/release-application', component: Application, name: '发布申请'
      },
      {
        path: '/release-list', component: List, name: '发布管理'
      }, {
        path: '/release-review', component: Review, name: '发布审核', meta: {role: ['admin']}
      }
    ]
  }, {
    path: '',
    component: Home,
    name: '消费管理',
    iconCls: 'el-icon-menu',
    children: [
      {
        path: '/consumer-application', component: ConsumerApplication, name: '消费申请'
      }, {
        path: '/consumer-list', component: ConsumerList, name: '消费管理',
      }, {
        path: '/consumer-review', component: ConsumerReview, name: '消费审核', meta: {role: ['admin']}
      }, {
        path: '/consumer-query', component: ConsumerQuery, name: '动态消费情况查询'
      }
    ]
  }, {
    path: '',
    component: Home,
    name: '系统管理',
    iconCls: 'el-icon-setting',
    children: [
      {
        path: '/userinfo', component: UserPassword, name: 'Vhost用户名密码管理', meta: {role: ['admin']}
      }, {
        path: '/prodline', component: ProdLine, name: '产线管理', meta: {role: ['admin']}
      }, {
        path: '/appname', component: AppName, name: '应用管理', meta: {role: ['admin']}
      }, {
        path: '/systemconfig', component: SystemConfig, name: '系统配置', meta: {role: ['admin']}
      }
    ]
  }, {
    path: '',
    name:'统计分析',
    component: Home,
    iconCls: 'el-icon-picture',
    children: [
      {
        path: '/statistics', component: Statistics, name: '生产消费关系', meta: {role: ['admin']}
      }
    ]
  }
]


export default routers
