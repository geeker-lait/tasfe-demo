window.res__ = "http://192.168.25.61:8989";//sat
// window.res__ = "http://172.16.11.81:8989";//sat
